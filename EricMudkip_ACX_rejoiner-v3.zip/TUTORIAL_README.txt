========================================================================
ERICMUDKIP ACX REJOINER - DOWNLOADS, SETUP & USAGE TUTORIAL
========================================================================

1. WHAT IS INCLUDED IN THIS ZIP
------------------------------------------------------------------------
- EricMudkip_ACX_Rejoiner.ahk : Main AutoHotkey v2 macro script with GUI
- rejoin_settings.ini         : Saved configuration file (Rejoin + AutoClicker)
- disconnected_ref.png        : Pre-cropped "Disconnected (Error Code: 769)"
                                reference image (also embedded cleanly in .ahk)
- README.md                   : Formatted GitHub README with clickable links
- TUTORIAL_README.txt         : Easy-to-read Notepad tutorial (this file)

2. USING THE AUTO-CLICKER (MINUTES, SECONDS & SET POSITION)
------------------------------------------------------------------------
Inside the "Auto-Clicker Settings (Anti-AFK / Farm — Hotkey: F4)" section:
- Interval (min / sec)   : Enter how many minutes and/or seconds between clicks
                           (for example, 0 min 5 sec, or 10 min 0 sec).
- Click at set position  : Check this box to click a fixed X / Y coordinate.
                           Leave unchecked to click the center of Roblox (in
                           background mode) or your current cursor position.
- Pick Position (Click)  : Click this button, then click the exact spot you
                           want to auto-click to automatically fill in X & Y.
- Background click       : Sends clicks directly to RobloxPlayerBeta.exe in
                           the background without moving your real mouse cursor.
                           Uncheck if you want physical cursor clicks on screen.

3. HOTKEYS
------------------------------------------------------------------------
- F1 : Start / Stop background rejoin monitoring
- F2 : Test Rejoin Now (forces immediate rejoin using your saved link)
- F3 : Show / Hide the EricMudkip ACX Rejoiner GUI window
- F4 : Start / Stop the Auto-Clicker
========================================================================

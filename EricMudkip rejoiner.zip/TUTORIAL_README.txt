========================================================================
ERICMUDKIP ACX REJOINER - DOWNLOADS, SETUP & USAGE TUTORIAL
========================================================================

1. WHAT IS INCLUDED IN THIS ZIP
------------------------------------------------------------------------
- EricMudkip_ACX_Rejoiner.ahk : Main AutoHotkey v2 macro script with GUI
- disconnected_ref.png        : Pre-cropped "Disconnected (Error Code: 769)"
                                reference image (also embedded inside the .ahk)
- README.md                   : Formatted GitHub README with clickable links
- TUTORIAL_README.txt         : Easy-to-read Notepad tutorial (this file)

2. REQUIRED DOWNLOADS (PREREQUISITES)
------------------------------------------------------------------------
- Windows 10 or Windows 11 (uses built-in Windows.Media.Ocr.OcrEngine API:
  https://learn.microsoft.com/en-us/uwp/api/windows.media.ocr.ocrengine?view=winrt-28000)
- AutoHotkey v2.0 or newer:
  Official Download: https://www.autohotkey.com/v2/
  Microsoft Store:   https://apps.microsoft.com/detail/9plqfdg8hh9d
  Install Guide:     https://www.autohotkey.com/docs/v2/howto/Install.htm
- Roblox Desktop App (RobloxPlayerBeta.exe) for direct roblox:// deep links:
  https://create.roblox.com/docs/production/promotion/deeplinks

3. STEP-BY-STEP SETUP TUTORIAL
------------------------------------------------------------------------
Step 1: Extract all files from "EricMudkip ACX rejoiner.zip" into a folder
        on your PC (do not run it directly from inside the unextracted ZIP).

Step 2: Install AutoHotkey v2 from https://www.autohotkey.com/v2/ if you
        don't already have it installed.

Step 3: Double-click "EricMudkip_ACX_Rejoiner.ahk" to open the GUI window.

Step 4: Paste your Roblox Private Server Link or Game URL into the
        "Private Server Link or Game URL" box:
        - Supports new Share Links (https://www.roblox.com/share?code=...&type=Server
          per https://devforum.roblox.com/t/private-server-help/3934961)
        - Supports classic Private Server Links (privateServerLinkCode=...)
        - Supports normal Roblox game links (https://www.roblox.com/games/...)
        Click "Save Settings" to save your link to rejoin_settings.ini.

Step 5: Press F2 (or click "Test Rejoin Now") to test your link and make
        sure Windows launches Roblox directly into your server.

Step 6: Press F1 (or click "Start Monitoring") to start scanning your
        Roblox window every 5 seconds in the background.

4. USING THE BUILT-IN IMAGE REPLACER
------------------------------------------------------------------------
The macro comes pre-loaded with the "Disconnected (Error Code: 769)" image,
and even if "disconnected_ref.png" is deleted, the script automatically
restores it from its internal backup.

Inside the "Detection Image (Built-in Image Replacer & Preview)" box:
- "Replace Image (Browse File...)"     : Pick any custom .png, .jpg, or .bmp
                                         screenshot from your PC to replace
                                         the detection image immediately.
- "Capture Image from Roblox Window"   : Automatically snapshots the center
                                         dialog of your open Roblox window
                                         and sets it as the detection image.
- "Restore Built-in Default Image"     : Resets the detection image back to
                                         the built-in Disconnected (Error 769)
                                         prompt at any time.
- "Tolerance (0-255)"                  : Adjusts pixel color variation tolerance
                                         for ImageSearch (default: 50).

5. HOTKEYS
------------------------------------------------------------------------
- F1 : Start / Stop background monitoring
- F2 : Test Rejoin Now (forces immediate rejoin using your saved link)
- F3 : Show / Hide the EricMudkip ACX Rejoiner GUI window

6. TROUBLESHOOTING
------------------------------------------------------------------------
- Do not minimize Roblox completely to the taskbar; leave the Roblox window
  open on screen (it can be behind other windows) so Windows PrintWindow and
  Windows OCR can read the pixels in the background.
- Keep Windows display scaling at a standard preset (100%, 125%, or 150%:
  https://www.vividrepairs.co.uk/screen-ocr-hotkey-windows).
========================================================================

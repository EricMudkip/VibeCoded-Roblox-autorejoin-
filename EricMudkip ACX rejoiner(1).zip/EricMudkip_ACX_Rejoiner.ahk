#Requires AutoHotkey v2.0
#SingleInstance Force
Persistent

; ==============================================================================
; EricMudkip ACX Rejoiner - Background OCR, Image & Crash/Popup Auto-Rejoin Macro
; ==============================================================================
; Reference Links:
; - AutoHotkey v2 Documentation: https://www.autohotkey.com/docs/v2/
; - Roblox Deep Links Documentation: https://create.roblox.com/docs/production/promotion/deeplinks
; - Roblox Share Link Protocol Format: https://devforum.roblox.com/t/private-server-help/3934961
; - Windows.Media.Ocr.OcrEngine API: https://learn.microsoft.com/en-us/uwp/api/windows.media.ocr.ocrengine?view=winrt-28000
;
; Features:
; 1. User GUI to input and save any Roblox Private Server Link, Share Link, or Game Link.
; 2. Built-in Reference Image Replacer & Preview:
;    - Pre-loaded with the Disconnected (Error Code: 769) reference image.
;    - "Replace Image (Browse File...)", "Capture Image from Roblox Window",
;      and "Restore Built-in Default Image" buttons.
; 3. Complete Disconnect, Crash & Startup Failure Recovery:
;    - Detects in-game "Disconnected" / "Error Code: 769" via background Windows OCR + ImageSearch.
;    - Detects the Windows popup "Failed to download or apply critical settings, please check
;      your internet connection" — automatically clicks "Retry" first, and if it persists,
;      closes it and re-launches your server link.
;    - Detects if Roblox is NOT open at all (crashed, closed, or failed to launch after a link)
;      and automatically retries launching your server link, with an automatic browser URL
;      backup if direct `roblox://` launch fails repeatedly.
;
; Hotkeys:
;   F1 - Toggle Background Monitoring ON / OFF
;   F2 - Force Rejoin Immediately (Test Link)
;   F3 - Show / Hide Configuration Window
; ==============================================================================

global ConfigFile := A_ScriptDir "\rejoin_settings.ini"
global ReferenceImage := A_ScriptDir "\disconnected_ref.png"
global TempCapturePath := A_Temp "\roblox_ocr_capture.png"
global TempTextPath := A_Temp "\roblox_ocr_result.txt"
global OcrScriptPath := A_Temp "\roblox_win_ocr.ps1"

global IsMonitoring := false
global LastRejoinTick := 0
global LastNoWindowTick := 0
global ConsecutiveLaunchFailures := 0
global CriticalPopupCount := 0
global CheckIntervalMs := 5000       ; Scan every 5 seconds
global RejoinCooldownMs := 35000     ; Cooldown after launching when Roblox window is open
global NoWindowRetryMs := 20000      ; Retry after 20 seconds if Roblox fails to open at all
global TargetWindow := "ahk_exe RobloxPlayerBeta.exe"

; Load saved settings (never store personal links in the default script)
SavedLink := IniRead(ConfigFile, "Settings", "ServerLink", "")
SavedDirectProtocol := IniRead(ConfigFile, "Settings", "UseDirectProtocol", "1")
SavedCloseBeforeRejoin := IniRead(ConfigFile, "Settings", "CloseRobloxFirst", "1")
SavedRetryIfClosed := IniRead(ConfigFile, "Settings", "RetryIfRobloxClosed", "1")
SavedHandleCriticalPopup := IniRead(ConfigFile, "Settings", "HandleCriticalPopup", "1")
SavedClickReconnectFallback := IniRead(ConfigFile, "Settings", "ClickReconnectIfNoLink", "0")
SavedUseImageSearch := IniRead(ConfigFile, "Settings", "UseImageSearch", "1")
SavedImageVariation := IniRead(ConfigFile, "Settings", "ImageVariation", "50")

; Ensure built-in reference image and OCR helper script exist on startup
if !FileExist(ReferenceImage)
    RestoreBuiltInImage(false)
InitOcrHelperScript()

; ==============================================================================
; GUI Construction
; ==============================================================================
MainGui := Gui("+AlwaysOnTop", "EricMudkip ACX Rejoiner")
MainGui.SetFont("s9", "Segoe UI")

MainGui.Add("Text", "x16 y12 w480", "Private Server Link or Game URL:")
LinkInput := MainGui.Add("Edit", "x16 y32 w480 h24 vServerLink", SavedLink)

ChkDirect := MainGui.Add("CheckBox", "x16 y64 w480 Checked" SavedDirectProtocol, "Launch directly via roblox:// protocol (with automatic browser backup)")
ChkCloseFirst := MainGui.Add("CheckBox", "x16 y86 w480 Checked" SavedCloseBeforeRejoin, "Close disconnected Roblox client before rejoining via link")
ChkRetryClosed := MainGui.Add("CheckBox", "x16 y108 w480 Checked" SavedRetryIfClosed, "Auto-retry rejoining if Roblox is not detected open / fails to launch")
ChkCriticalPopup := MainGui.Add("CheckBox", "x16 y130 w480 Checked" SavedHandleCriticalPopup, "Auto-fix 'Failed to download or apply critical settings' popup (Retry + Rejoin)")
ChkReconnectBtn := MainGui.Add("CheckBox", "x16 y152 w480 Checked" SavedClickReconnectFallback, "Click in-game 'Reconnect' button instead if Server Link is left blank")

; --- Built-in Image Replace & ImageSearch Section ---
MainGui.Add("GroupBox", "x16 y180 w480 h178", "Detection Image (Built-in Image Replacer & Preview)")
ChkUseImg := MainGui.Add("CheckBox", "x28 y202 w300 Checked" SavedUseImageSearch, "Enable ImageSearch alongside Background OCR")
MainGui.Add("Text", "x338 y202 w85", "Tolerance (0-255):")
EdtVariation := MainGui.Add("Edit", "x430 y199 w50 h22 Number", SavedImageVariation)

PreviewBox := MainGui.Add("Pic", "x28 y230 w210 h114 +Border", FileExist(ReferenceImage) ? ReferenceImage : "")
ImgPathLabel := MainGui.Add("Text", "x250 y230 w234 h34 cGray", "Active Image: Built-in default (Disconnected / Error 769)")

BtnReplaceFile := MainGui.Add("Button", "x250 y266 w234 h26", "Replace Image (Browse File...)")
BtnCaptureWin := MainGui.Add("Button", "x250 y296 w234 h26", "Capture Image from Roblox Window")
BtnRestoreDef := MainGui.Add("Button", "x250 y326 w234 h26", "Restore Built-in Default Image")

BtnReplaceFile.OnEvent("Click", (*) => ReplaceImageFromFile())
BtnCaptureWin.OnEvent("Click", (*) => CaptureReferenceFromRoblox())
BtnRestoreDef.OnEvent("Click", (*) => RestoreBuiltInImage(true))

; --- Status & Main Controls ---
MainGui.Add("Text", "x16 y368 w50", "Status:")
StatusText := MainGui.Add("Text", "x65 y368 w430 cRed", "Idle (Press F1 or click Start Monitoring)")
LastOcrText := MainGui.Add("Text", "x16 y390 w480 h34 cGray", "Last Scan: None")

BtnToggle := MainGui.Add("Button", "x16 y430 w152 h34", "Start Monitoring (F1)")
BtnTest := MainGui.Add("Button", "x180 y430 w152 h34", "Test Rejoin Now (F2)")
BtnSave := MainGui.Add("Button", "x344 y430 w152 h34", "Save Settings")

BtnToggle.OnEvent("Click", (*) => ToggleMonitoring())
BtnTest.OnEvent("Click", (*) => TriggerRejoin("Manual Test"))
BtnSave.OnEvent("Click", (*) => SaveConfiguration(true))

MainGui.Show("w512 h478")

; ==============================================================================
; Hotkeys
; ==============================================================================
F1::ToggleMonitoring()
F2::TriggerRejoin("Hotkey F2")
F3::
{
    if WinExist("ahk_id " MainGui.Hwnd) && DllCall("IsWindowVisible", "Ptr", MainGui.Hwnd)
        MainGui.Hide()
    else
        MainGui.Show()
}

; ==============================================================================
; Built-in Image Replace Functions
; ==============================================================================
ReplaceImageFromFile() {
    global ReferenceImage, PreviewBox, ImgPathLabel, MainGui
    MainGui.Opt("-AlwaysOnTop")
    SelectedFile := FileSelect(3, , "Select Replacement Disconnect Detection Image", "Images (*.png; *.jpg; *.jpeg; *.bmp)")
    MainGui.Opt("+AlwaysOnTop")
    if (SelectedFile = "")
        return

    try {
        FileCopy(SelectedFile, ReferenceImage, 1)
        RefreshImagePreview("Custom file: " RegExReplace(SelectedFile, "^.*\\", ""))
        TrayTip("Detection image replaced!", "EricMudkip ACX Rejoiner", 1)
    } catch as Err {
        MsgBox("Failed to replace image: " Err.Message, "EricMudkip ACX Rejoiner", "Icon!")
    }
}

CaptureReferenceFromRoblox() {
    global TargetWindow, ReferenceImage, OcrScriptPath, TempTextPath
    Hwnd := WinExist(TargetWindow)
    if !Hwnd {
        MsgBox("Roblox window (RobloxPlayerBeta.exe) is not currently open. Open Roblox first to capture the dialog.", "EricMudkip ACX Rejoiner", "Icon!")
        return
    }
    Cmd := 'powershell.exe -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File "' OcrScriptPath '" -Hwnd ' Hwnd ' -OutPath "' ReferenceImage '" -TextOut "' TempTextPath '"'
    try {
        RunWait(Cmd, , "Hide")
        if FileExist(ReferenceImage) {
            RefreshImagePreview("Captured from active Roblox window")
            TrayTip("Captured center dialog from Roblox window!", "EricMudkip ACX Rejoiner", 1)
        }
    } catch as Err {
        MsgBox("Failed to capture from Roblox: " Err.Message, "EricMudkip ACX Rejoiner", "Icon!")
    }
}

RestoreBuiltInImage(ShowNotification := true) {
    global ReferenceImage
    B64Parts := [
        "iVBORw0KGgoAAAANSUhEUgAAAYUAAADtCAYAAABQ82nLAABdAklEQVR4nO29d3hVVbr4/9nlnJCEhASkd6QJoQokNEGpQREFkWIvM7876szc6zSdpvMVdcqd",
        "UUdnLCN2vaOOOoAgIKBjoUS6RqlJ6J30cs7Z5ffHPmtln0NCCSgB1ud5eBJO9tl77bXXft/1lvUubfCQ4S6AC6C5aC4AaN4PXPFTfFAnXDRXAzQ0tOhZ3eMe",
        "X3MrTtSIU2+kvyVanc6gUNQXjvdOnQlqezu06JXdb70Fx+d0314XKQDjzxz38enJw9ouX/tJtbifx3w17uep4j+/GXOZavVwhh+uhtAF7gkVgr+Jtf2/tu/U",
        "TSmIr7lnd0QrFGeAb2sQn8z7dbanVKd577UohO8E9+Tk17fdQhcw4y/yrWhAqi2Rb43TOLXfUlB6QXFO823J5XPlxfiWZMy3JRdP+vrf0fl1XcOMudzZ1JQx",
        "1MF9pLl16zkt7vf60gUKxanybb6/dX2/vkvqjfyqA/Wkfx3HxTynOzKeM3EvZ9sCVijqK+eTrKiP1JP+Nc92A2qmLjEFhUKhUJwu+tlugEKhUCjqD/XUUvhu",
        "UXaIQqFQeJjfSf6tQqFQKM4JdLVgS3Gm0LXaR5Lr1I8gWn1G9ZGiPiBjCkoxKPwcT8DXBVetDDwh8X10pp7BmX6WivMbFWhW1Ijjuhi6gaEbAJiGF35yHRfH",
        "dnBsB9uy5WdC8LiOi+u4dO3SlUcefoTv3Xknju3IvylqRze811HXtDMiyEV/O65Li+Yt+OzTT/n8s08ZcdkIpSgUtaICzYpasR1P6A+4dACPP/4Ymga27Qma",
        "srIy8vLyWLZsGfPnz6eqqgrTNDEMTwjdcsstXD5iOCNGDGfp0mVs27YNTVeC6Hi4jsuTTz5J3759eeihh/hwyYdn5LxKAShOBWUpKGrF0A1sy8ayLIxo+SpN",
        "09A0jbRGKfTr14d77/0fXnnlFTp37oxlWdhRq+CTTz+hrKKKjRu/ZP/+/eiGflLC6UTHnIy1Ud8skpNtj2maJCUnYRoa4XD4W26VQlEz0lKoX6+Roj4QDofR",
        "dR3TNHGin91xx+3k5eXTslVLrpxwJdOmTaNVq5b84Q+/55ZbbqGyshKAZUuXsWjRIgxdx3VdNE2rcYzFZ79pug6u/a3eVzy6puGcIOZxbDu975yp7D3NBce2",
        "SW2Y4lWqNA2v8sFJnu+k7kHzij6q+I7ieOgnU7NUceGhaxqGaUSFnyNrZLqug2Vb7Nm9m2eefYYHHngATdNo1bIF11xzDbZto2katm0BLpZlecJT09E0Hdt2",
        "0HVDxigALMuq8fqisLmhaxhxricR23AdF9MwY/zwmq7J2AYg4yLie35rxDRMNK3aitE1LSaWYlu2/N1xHAzDQDcMeayma1LIip+mYcrru44r3Waijf5rCWzH",
        "wTA0LrqosdcnkQia7h0rYjKiP1zXwdA1dA0c28J1HRzXO0Yc69iO/L5l2YTDYVzXUwzACRWI4sLFVOsSFHVB07wZ/YoVy9myZTPdunVj9OhRvPnmPwGNadOm",
        "cffdd1FVVcXYseOwLItAMMjMmTOZOPEqWrVsRXl5GWtWr+Ef//gHe/bswXFdXM0T4tnZ48mekE33bt2wbYsvv8rluWefY/OWLTi2Q0JCAtdffz3js8fTpnUb",
        "yspKWb9+A2+88QZbtmzB1Rwc1+WGmTfw/e9/j3nz3uftt9/mjjvuYNCgQQSDQTZu3MgTTzzBjh0FOK6nLG666Wa+9707mTt3Hm+++Sa33norWVlZJCUlsmH9",
        "Bv7y57+wY+cOaSnguASDQWZMn86YsWNp06YNxcXFfPLpJ8yePZvS0jJc11Nehmkybtw4xowZQ48ePdA0ja+++ooXXniBIUMGM/3660lICALw+0cfwQUqq8KM",
        "GTMaTdMwDIMZM6Yzesxo2rVtS0lJCZ9++hnPPfcsJSWl2LaLaRokJSVz++23c/nll9O06UV8880mXnnlFUBZCooTowLNijrhug66phEKhVi9Zg3du3Wja9eu",
        "WLYNaJ7SwBNAtuPNXu+8/XZm3nADAUPDAUwzjXFjR3PpwIFMnz6dUFUVmqbx8MMPk5WViWFUn2PggAE0aJDIXT+4i+TkJP7yl7/Qq1cvwFtsE2yczsiRIxkx",
        "YgS/feC3fPzxx96M39AxDIORI0cyYcIEEhMCuIDjwsCBl/Lb3/6W226/DSBqydhoGgwdNpTx48fTIHq8Dgwc0J8HH3yQ226/zTs2EiY1NZU//+lP9OnTS/ZN",
        "s6ZNmHzttfTp3Ycf/NcPqKysIBgM8tCsWWRlZREwNKLxegYMuJSkpCS2bt2CGfBex0gkQiAQwHGJWlwQDAb53z//L7179cLQvX5p1KgRkyZNIqNXBt/73vex",
        "K0M0bJjC448/TvduXWS7e/TozqOPPvJtDQXFeYYKNCvqjG07uK7LkcOHAU94p6amAuA4cXEB12VCdjYBQ+Ofb/2L8eMnMH36dN54823+9ve/U15RjmVbzJw5",
        "g2FDB2MaOm+++SbXXXcdkyZN4sUXX2LWQw8RCAS47bbbycjoheO4PPHEX5lw5VXcdNMtfP311wQMjft+cR+N0xvjRl0qugZpaY3YsWMHt93xPUaPGce//vUO",
        "AJ07d6Z9u/aem0e4n4AmjRuTl5/HLbfextix43n7X+8C0KVrZ9p36OApRV3nhhtuoFfvXhQXl3LvvT/liitGc+ONN7N502a6dO7ExIlXoWka066/nuFDB2Ma",
        "Gm++/Q7XXTeVSZOuYfbsF/jd737Hn/74J6ZMnoLjOJimya9//RuGDhnC6NFjALjpppvo36cPxcXF/ORnP2XkFZdz8823kJuby8WdLmbK5MkYhs6MGTPo2rUL",
        "tgPPPvsc2dG++fSzz9CUV0BxEiiloKgV4f92HTc6u3alL1pYAsFg0IsZ4CkF6cc3jzVCC4uKAGjTpg2NGjViz549PPbYYyxc+AGapqHrGlOnXgfAypwc/vrk",
        "U+zbf4AjRwt58aWXOHDgAK7rMmHCBHQdlixZwrvvvsvRo4UUFOTz0EMPYTnQsGEy48aNk221HaiqCnH33XezafMmqqoqeeutt+ROe+3atQO8GbquewHxqqoQ",
        "P/rhj9i+fTtVVVW89dZb0T7x2m/bnvC++uqr0TV46smnWLN6DeFwmIKCAumuGTx4CADTZ8zABVaszOGxxx5j3759HD58mBdeeIHdu3dX97mue0F510XXDS9r",
        "SzeYNGkSEdvmmWeeYdXKldiWzc6dO/jnP/8Px3Ho378/ABOunICuwapVq3jttdcoKi4mLz+PJx5/Qt6vdobWQSjOT5T7SFFnDEPHsmxatWyJi5etVFpWiusg",
        "XRwCF/jfP/+ZP/7hDwwenEVWVhbbtm1j7ty5zJk7F9u2aNr0ItLS0nBcl+XLlx9zPU3TSU9PJz29ERrw1VdfYTs2erQdu/fs5vDhwzRvdhGdOnWS39E0TxBW",
        "VVV6AWodQqEQALoeFcTRYLCm6dGArHc8eK6yyqoq2Y6AaaLpGo0bN6ZJeiMA7r//fn716/sBzzUl4uKtWrXkoosuIi0tFQ1YuXIlhqEfE+jVotesvlcNx7HR",
        "DIO0tDQapzXCchzuu+8+7rvvvujfHQxdRwPatW9PYmIijdO9QPVXX311ys9ToQBlKShq4WSzUwIBkwEDB+ICX3/9tfw8HA7HbmqnaXyV+xXTZ87g739/mry8",
        "PLp17czPf3ovT/31rzQIJnjZPHJltMOp4jqul/5KvID1fkYilszIiUQinrIA+ZkeJ5Rt2/H9q86Q0g3Ds6Bc30b10TfJ9mX4AERsGzQN2zn9LD/dp2gdx5H/",
        "d4hVclBzRpd3X6fZCMV5j7IUFLUiMnKqVyJrx/z98hEj6NihIxrwn08+wbZsEhISCAQCUeFcLcgMw6SwqIjXXnuN119/naysLP70pz/Rp09vLrtsOMs+WkZx",
        "cTFpjRqRlTWYd959L+Z6rutQWFhIYWEx6emNyMjIYM6cOUQiEUzToEULb1buAPn5+eiahm3bcuZvmNFUUt1Aj96Ty/EXlxlR943ruNgOGLq3ngDg6NEjlJSU",
        "kZLSkL/85THmzJ0rYym6bkTb5b1iZWVlpKY2JCsrS7qiaurvmL7XDVygqKiIo0XFpKU14o9/+hNz586VGUSGXm11GLpBSUkZaakN6d69e633pFAcD2UpKGrF",
        "n+cvYgamYWLoBi1btuT73/s+D/2/32FosD2/gHnz3kfXDcLhCJZl41Cd/hgMBnn673/nN7/+DRdffDHBYJCSkhLAc7XougFoLF68BICsrCx+/KMf0/SipjRM",
        "bsjU66Zy7bWTcV2HuXPnAjB27BiuueYa0tLSaNu2HQ888AABQ6O8vIKFCxd6bTcMHMfFtm1pCXhWQtRNBCQkJBAOR+R9e4u8vHaLHH/dMNB1sBzPUhArt+fM",
        "nYumwY//+78ZP3486emNCQSC9O3blx/+8B4ikQi2Y7No0SJcF7KyBvGjH/2Ipk2bkpqayvTp07juuuvQNI2jhYXY0a16x40bT1JyMhc1uQjHsZk3730cx+Wu",
        "u+7m6qsn0Ti9MQ0aJNK3X3/uufseHNslErFYuXIltgtDhw7l6quvJjkpmS6dOzPr4VkYUZ3uRteNiBpW/jUdCoWyFBTHIASEaZpe6QrHxgUMXeP552dLF4Su",
        "ef7zHTt28Mtf/pLKikpc1yUQMNF1HR0IBALomkZGRgbdunWjZ4/uXJU9TqZkGhrs2LWHzz7/HNtxeOmlF+nbty9dulzMtOuviwpM79iqqhALFy7ktdde49JL",
        "L6Vnzx789N7/5qf3/jcuXkDZcuBPf/pfioqKpODWdQ1d9xbOicVmuq7L9ocjYU95+GbqrgyoazF5/Zrm1YQyTRPbsXn55Zfp27cvGRk9+NX9v5DuIx2vLatW",
        "5ZCTk8Ps2bPlfc2Yfj0zpl+PWJ5XXFLG4sWLKS8vY/HiDxk/bgwjLhvGZYsXUhWKMHHiRF5++SX69+9Pjx6X8Iuf/4z7fv4zhBx3HJflK1awYf0GZs+eTWZm",
        "JqmpKfzsZz/lFz/7KQ5QVRUmYrsEDC16Tw5m1HJSC9kUfpSloDgGTfdcRqIgnuerr/aJuy4UF5ewes06nnzySe6880527dqFaRoEg8HoMZ6/3YpWUt2wYT03",
        "33wz8+Yv4GhRCbZts2fPXubOX8BPfvITyivKcR2XouJi7rnnHv7xj9ls256P67qUlZWzYsVK/ud//oeysjIqKiu45557eOGFF9myLQ/LgbLyCj755BPuuusu",
        "Fi9eDHiuH9u2cRxPCYjsKN3QPWuBqAD3ubhc1yEctrwaT7pGIBAgISHBC+z6ZKfw2VdVVXLPPffw1FN/Z/PW7YRCYcrLK9jwZS6/+e1vZGC5pKSEu+++m+ee",
        "e56CHbuwbJeyiio++3wFP/3ZTykvLwPgscceY978BZSWV1BZFWb37t2kpaVRVlbOD3/4Q5588km2b8+nKhShsrKKdevW87vf/Y41q9dgOzYHDhzg7rvv5j//",
        "+YSKiirKK0N8/vkK7rzzTnJzvyIcfR4ik0wpBEU8WtbQYWpUKGrEKwHhLVALBoPSXx4zo46WcRC1d/RogFbTvXIRXgkGtzoIHJ32i4Vpfn+46zpEIp6wDUQX",
        "com/i+uI8wSDQU+w11D+Qpzfcb1SGP5jRdkH0zSOEYiO7aBpmrSQxHksyyYQCMh7qe3e4+/R317d0L1Vzb77dh3XW6Tm2GiajmVZ1XWioj/9JTJE/1qWTTAY",
        "xLItHNub8VuWLYsO2rYTVYiOvAfxTEzDlNcT6zjk/SsFoUApBcUZQPjqhTA6VeESnzN/ou8L4VrbcY7tSCF8KuW6xfdOBr8Pvi73XNP5vuvS4qfa74oLAxVT",
        "UJw2ckFbHYWamAGfrFCSdYdq+7tvpn4qaNrJHy+sgDPF2dhrQikBRU2omILijFJXQVMfBNTpKDWF4nxBWQqK847vatatdpJTnI8oS0GhUCgUEqUUFAqFQiFR",
        "SkGhUCgUEqUUFAqFQiFRSkGhUCgUEqUUFAqFQiFRSkGhUCgUEqUUFAqFQiFRSkGhUCgUEqUUFAqFQiFRSkGhUCgUkjophfhNzhUKhUJRv6irnK5TQbzaqkKe",
        "jZrwCoVCoTiWulbvrZNSENrnoYdmAdX72fp3nVIoFArFd4+Qwb/5za+BU1cOp7XzWk07N53JjUcUCoVCcXL4t3o9lU2r4qnzfgrxCkHTdHQcHBW6VigUiu8c",
        "se+2kM11VQx1VgrHXMy163oqhUKhUJwmtnNmZLCa1ysUCoVCopSCQqFQKCRKKSgUCoVCopSCQqFQKCRKKSgUCoVCopSCQqFQKCRKKSgUCoVCopSCQqFQKCRK",
        "KSgUCoVCopSCQqFQKCRKKSgUCoVCopSCQqFQKCRKKSgUCoVCopSCQqFQKCRKKSgUCoVCopSCQqFQKCRKKSgUCoVCopSCQqFQKCRKKSgUCoVCopSCQqFQKCRK",
        "KSgUCoVCopSCQqFQKCRKKSgUCoVCopSCQqFQKCRKKSgUCoVCopSCQqFQKCRKKSgUCoVCopSCQqFQKCRKKSgUCoVCopSCQqFQKCRKKSgUCoVCopSCQqFQKCRK",
        "KSgUCoVCopSCQqFQKCRKKSgUCoVCopSCQqFQKCRKKSgUCoVCopSCQqFQKCRKKSgUCoVCopSCQqFQKCRKKSgUCoVCopSCQqFQKCRKKSgUCoVCopSCQqFQKCRK",
        "KSgUCoVCopSCQqFQKCRKKSgUCoVCopSCQqFQKCRKKSgUCoVCopTCOYSuaTE/FfUbXdNqfVY1fe467nGPPd75xPdrOqa28yrOHOdTH9crpXC8AS/+ZuhGjQP/",
        "QhCUmqbLnycSEIr6jeMeK0TcGj47VTRNl+ME6u974W9XfW3jqXAmnl19oV4pBf+LImY9ju0A1YLQdR15nK5p8rgLgUgkgmmY2I4tX/wL5d7PVTRNx7EdDN3A",
        "dVz5O1Q/O/G54zhyvDu2g2mYMZMh2/bGvvjMsb3jXcfF0A0MQ0waNPluABiGHvM+iYnV2cR/H3BujmPXceWzM03jbDfnjGGe7QbE4zoumh4d9K6LHh3QNnbM",
        "y2AEAtiOjWHo2LaDaZrg2mez6d8qruOiaRqO4/WDZVmynxT1D7+QGzlyJIMHDyYQCPDqq6+Sn5+PbuhYlo2maWi6hoaGFv1OwAxw1TVX0bRpU5555hlM05Bj",
        "3U8gEADAdmzv77qB6zrYUWEljrdthylTptCkSWP+8fzzuK6DZdnoxpmdE+qaVqMFVNuxAsf1BOuZbs+3zYgRI2jZsgVvvvXW2W7KGaXeKQU/YqCMHDmSUaNG",
        "oes6rutiWRaHDh1i48aNrFixAk13sZ3zVyEAaLpGyxYt+cEPfsCsWbPQdQfXdT0hYDtKQdQzhHBs3rQJo0eP5v333+frr7+mrLxMTnSEQoBYn3Q4HMZ1HQzD",
        "IBgMYtlW9YTIN8O2HRvXcY95PyoqKzh65Cifff4Zubm5BAIBdF3HiFoejusSiE6qzhbiPsSYfvTRR6isqjpr7akLrVq14qKLmhAMBAlHwme7OWeMeqcU4oWb",
        "sBwikQgPPzwLy7JJTU2lfYf2TJk8hYSEBD7++GMikcg5N9OI50QzLcMwME0T0zQJhULnvSI819E1jSZNLkLTNL78ciOhUAgA0zBxNFs+azHG/VayHnUxCcvQ",
        "P5v2f880TQzDoLKqkj/+4Y8YhkFycjI9e/bkhpk38Pbbb7Nhw3pCoRCO41kIgUDgW7E0NU3HtU98XnGfjutiGAaGYeCcQ4Fa8TzeeOMNAoEAoVCIYDCI4zpn",
        "u2lnhHolRf1ZFpquYZqeEHQdVwZyTNOgtLSUb77+mtWrV9O7d2/C4bA0vaF61iX8reL/MX7WqI9XfObYTo1ZHsLHa+jGMb7hmr4rrlfTtfxt8l/fj7ieaIP/",
        "3MFgENv2XA6u6xAwAzH+aeErtq1qV5v4TFw3xgftuxf/M/C3S9c0TMOUxwYDwRhfqugX4f8W92lbdswz9feB67jyeNFuf9+ZhinPETADMe0TfSTab0UsT8jG",
        "PQPRbvGzprHgv67/3uOP9d+rf0Yffz3/s3AdF8d1SUpKQtM0z10T/b5lW1iWXX1+1z2mLeJzR/yrwW+t6VrUUvRcR5ZlYVkRSkpKWLFiBZs3b2bAgEvRNJ1g",
        "MIiu69JC8LuiRPtty5bP09+f4p78/SLGkH+8RiIRDEOP+Z5/nMkxEr1fXdM8Yeo46Hp1/DBgBuT5xbn9Y6WmTJ/490h8V4yX+Mw913Gxo8/An7zib6//Pfb+",
        "Do7tU+auJ5c0zXNhuw6yH/3jR4znc4V631rbsT2fq98H6TgYhk5CQgIARvRl6ZXRi5EjR5Kens7hw4fJycnhiy++8GYltkPX7t254ooraNasGZWVlWz8ciPL",
        "li4DLLp06cq4ceNo1qwZRUVF5OTk8Mmnn6AbOoZucOVVV6JrGgUFOxgxYgRpaWns27ePuXPnsnfvXhzXZfK1kwHIy8tj2LChNGlyEfv372fOnDns27dPDr7u",
        "3S9h1KhRNGrUiNLSUj7//HNWr1ktYyhdOndm5MiRtGrVmrKyUr7++mt03WDgoIEYhsH999+Ppmm88MILFBQUSIU5/LLhDB0ylD/84Q/eZ67NjBkz6NChA7Me",
        "nuUpW01n6tSpWJbF22+/TcuWLRkyZAidOnUiKSmJo0eP8MEHC9m2bRuGodO+fQfGjBlDs2bNKCkpYdu2bSxduhTLsjz3hesQDAaZOXMGoVCIN996C9dxCQRM",
        "xowdS0bPnvz5L38BYNI1k9A1jR07djJ8+HDS0tLYv38/7733HgcOHEA3dNq2bcuY0WNo1aoVpaWlbN26lSVLlhCOhLn1llu9a7z5TyKRCIFAgIkTr6Jr1278",
        "JXoNXdPo2PliRl4+krZt21JaUsJXubksXbKUcDhM9+7dGTt2DE2aXER5eTlffvUlSz5cAkBGRgaXXXYZTS5qwuFDh1i1KoecnBw0XaNNqzZcddVVNG/enIqK",
        "Cr7++mvZro4dOzJmzGhatGhJaWkpW7ZsYcmSJQwcOJDs7Gws2+KBBx5g586dPPeP57j1llsJh8P885//h+N6bqSxY8fQrVt3Hn/icTnO/RktWg1WpHieAhFf",
        "MwywLJvDhw/TvXs3IpEItm0BSAvBcV169+rNZZcNp3HjJhQWFrJy5UpycnIwTYPmzVswePBgunTpQnJyMgcPHmDBgg/Iy89D1zTatm3H2LFjaNGiJRUV5Wza",
        "tJklS5ZQWVmJbuj0uKQHo0aNku/iihUrWLNmDYFAAE1zcF2H7OwJZGZmomkav/rVr7Fsizdef4PNmzczefJkXNdh565dXHH5FZSWlrJr1y66du3KX//6hCcb",
        "okrk7rvvZnvedhZ+sFD2RdgK0759ewYMuJQuXbqS3DCZI4ePMH/+fHbu3Imj2SQlJTJu3Di6detOSkqK7GfXdZk9ezbhcJiBAwfQpUtXUlIacvDgAebPn8+O",
        "HTsBuGbKZJo0acrzz8/GMHQmTboagPz8fC677DI5vufM+Tf79x84Z1y89U4pxAegwNPqhmnguJ72TUlJoVu3bvTu3ZucnFXomkafPn0ZNWoUc+b8m4KCHbRp",
        "04brr7+esrIytmzZTK8+fZhy3RQ+XPwha9euIT29MV27dSUUCpGZmcmECROYM2cO33zzDR06dODqq68mJSWF+QvmY1kWhm7Qp28fbNvh+eefR9d1br31VrKz",
        "s3nhhReiL6hGRkYGoVCIl156mUAgwIwZMxg3bhyvvvoKAH379ePykSN599332LNnDy1btmT69OmUl5fzzaZv6NmzJ1OnTuWjZR/x2muv0ahRGl27duU///kP",
        "e/fuZfLkyTzyyMPSFQHIoOWWzVsYdcUo2rVrx7Zt2zBNg/bt21NVVUWH9h3Iz88nEDDo2KkjHyz4AIAOHTpwtPAoH7/gueBGjBjB1KlT+etf/0ooFGLatGms",
        "Xr2aV199hdTUVDIyemFZlnxWtu3IWbAZndWbpoEenXFBNHMm6gbp3bsPkYjFSy+9hK5rzJx5A1deeSWvvvoqmqZx44038kXOF7z++us0adKEnj17ejPJ6Muq",
        "Ra8JnoAT/nExPnpl9GLy5Ml89NFHvPnPN0lJSaFz585EIhH69+/PpEmTWLp0KevXryclJYUuXbqg6zoZGRmMHDmSuXPnsnv3blq0aMHMG2ZSVlbGN5u+4fbb",
        "byfnixxefPFF0tPT6N27D27ULz59+nTWrV/Hyy+/QqNGjejXrx+u6/LZZ58RCoW45ppr+N3vfofjRC0qXZfjW9c0HN1zF4mJjxhL/omQeA/8gsVxXXSqrSjL",
        "sr2gdPQZtGrVkiNHjkYFsS5jGLqmyXE4d+5cdu7cRatWrZg2bRqlpaVs2ryJdu3aUVxczLPPPkMkYnH55Zczbfo0/vLnv2BZFjNmzGDjxo28+OJLpKen07dv",
        "X+85GTr9+vZj1KhRvPvuu3KMT5s2jcrKSjZt3iSV0sKFC9m7dy9Tp07lwQcfxHEcIpEI4E0Gu3XthuO6PPvss1RVVZGWlkZWVhbt23cgLy8PgJYtW9KqVSvm",
        "zJkT0zcBw6RVq1aUlJQye/ZsysrKGDNmTPU92BaTJl1D06ZNmT17NqWlpVxxxeV07dqNJ6JKJ3NQJkXFxfzjH89RUVHJuPFjmTlzJv/7579gRSw0TScQMDFN",
        "g3DYiyn06tWLcDjMSy+9hGEY3HDDTLKzJ/DSyy/JZwjVbvKa5N3Zpl4phfhOie/AWQ/N8l5EXce2bXJzv2LZso9wXJfx2eOZ8+855OXlE4lE2L59O+vWraNn",
        "z55s27aNCRMmsH7dOnJycohYEUL797F3314aNGjA6DGjWb16NevWrUPTNbZu3cKiRYuYOnUqOTk5HDp8CNd1OLD/APPnvy9fvi+/+pLMQZlyhhaxIuzfv59F",
        "ixYRCoXQdZ1NmzYxePBgOaMbO2Ys896fR35BPoZusGfPHlavXk1GRgZbt27lqiuvYs3qNXz66ScYhsmRI0dYvny5J1BM85i+cmyHQCCAaZjs3beXkpISOnTo",
        "QF5+Hm3btqOwsJDde3bTuXNn8vPzSUtLIykxiR07dqDpWjRQX+36+OyzTxkwcACtW7eioGAHDRIbUFVVRUVFJeXlFRw+fATbsaXwN00vRdaJxjf0aF/I9jle",
        "MNzQDTRN5+DBgyxatMhzoUQscnNzGTZsmPecNY2EhAQqKyuJRMLs3beXgwcPSjeKbdvSSgRPCHqKybt2MBBkwoQJbNiwnk8+/QTXcSkrL2P37t0kJiaSPSGb",
        "jRs38umnnwJQWVnJgQP70TSdcePGec8lPw/bdigoKGDN6jVkZGSwfft2dF2nuKgYy4pw6NAhli1bhu3YBANBGiQ2oKSkhKqqKkKhEEuWfBidses4ruMFinWd",
        "cDhMIBDAcapdLlIxODa6HmsNa5p2jCLwB5z96LourYn09DT697+U5s1b8Oqrr0qLTnzfNANyHG7dtg3Xcdmxo4B169fRq1cvtmzZzIoVKzBNA8MwiVgRPvnk",
        "E7KysmjVqhV79+4lOTmZI0eOYNkWR48eZenSJTiu5yIanz2eBfMXUFCQTyRisXPnDjnGN23eFOMOBqRL1HHsaP94bqxQKMSC+QuIRCJousahw4fYtm0rAwYM",
        "IL8gH13T6NatG3v27GHP3j3HyJI1a9Z4csR1iEQsli9fTmZmJq1bt46+H21Zu3YtR48ewbYdcnK+YNiw4TRv1oxDhw7JPtA0nVCois8+/ZQhQ4bQqmVLdu7c",
        "JV13dvQddF1Xjm/HsYlELL788isGDx5cnRyAb6JbT2Og9Uop+BGdJvypVsTiN7/+DYGAyS233EppaSn/eudf6JpG82bNSE5K5sYbb5QDDDzzOz8/n6ZNm5KS",
        "ksKWLVvlrFOk5DVu3JjkpGS2bdsmX75wOMLOnTsAaNuuLQcOHPDyzR1P2JnRWWlZaRkpKSky+8c0TDm4DdPzS5aUlJCYmIjrOjRv3oLk5GRumHmDFGTgvdA7",
        "duygadOmNGzYkIKCAu++rYhMM9SiaaiA9Ecbho5uen93Xc93uXXrFjp06IBjO3S/pDs7duxg9+7dDB06lCVLl9C9e3cOHTpESUkJ4KU1tm3blh49etC+fXsa",
        "N26Mruk0bJhCOBzmgwUfMH78eDIyMli3bh3r1q2T7fbuO6q4NR3b9tZRYIAVdVcIRSaEkhb1PWu6hhkwqaysJDExUaZVzp07l4lXTaRHj0v48suv2LBhPeFw",
        "xPP3RgPtor/FczYMr6+bNGlCamoqmzdv8ZQFnmUZDAZJT08jOSmZTZs2SUUm+rNVqxakpKRw4403EglHooFPL7trx84dVFZW8sEHHzBu3Dj69u3L+vXrWbdu",
        "HW7EkYJr/Pjx9O3Tl7Vr15Kbm0tpaakcu9JiMnScqAIVAtyxHdy4eJij+/pLr47TCOUo/PvCKvDibyYPPvgggUCA4uJiDh06xKuvvsrevXulQhbfv+iii0hK",
        "SmLmjJlS+Xhj22Hvnr3S0mjfvgN9+vSmVavWpKamApCSkoJlWcybN4/s7Gz69OnDhg0bWL9+PaFwiObNm9MwuSFTp07l+uuvJ2J5M/+AGfBckrqBjY2pm964",
        "1jWZNWXb1Zl0rusQDoflOAJPoa1cuYoZM2aQlJhEaWkpffr04YvVX8j3QViRhqHjuo68hzZt2pCWlo5hGKSmpuI6Ll999SWXXNKdr776kqNHCxk6bChFRUUc",
        "OXLUa0fUTdavX1/atGlDw5SGRMJhUlNTsSxLWse6rsUEykWbdV2noqJCuqbEMxSB/pg1J/XESoB6rBT8iFlFIGDiuC4ff/wxd9xxB6tyVrFn925pej///PNs",
        "3brVmzVFZ7+u69CsWXN5LiEIRKqfMNN1XZfHJyQkRF0i1Zo83pQ/po0nyJ5w3OrZ0ezZs8nPz4u2pzpfvEXzFtGXw5bntBxLBt0Nw0DX9Rj3Q8w1bIvNm7cw",
        "depUEhISaNOmDZ9+8in79u3j2snXkpyUzMUXX8y2bduwLAvXdRkzfjQDBgxk+fLlLFy4kMLCQn7yk5/gul5my4oVK/j666/p0aMHQ4YMYfjw4cyePZvCokLZ",
        "RtP0XCKmaXrtj6ZKCpMaqv2/x+s/13VZs3oNWzZvoWfPngwePJjLLruM559/niNHjqDrOpFIxFPsVCtpIVwcx5YuJi+zRUfXjahPvVr4iTEghIhlWUSsCK/M",
        "foVt27bFZLGZholhGqxe/QW5ubn06tWLgQMHMnz4cF544QWOHD3CmjVr+Prrr+nVuxeZmZmMGDGC559/nqKiwpgJit//7w8uCzRNr85C8h1rmiaWZckgsabp",
        "6IYn4EW8LBKJ8NCshzAN7xlEIhE5y3VdR1oS1W3x3pft27f7lKsu+23cuHFceukAVqxYwYIFCygqKuQnP/kphuH1Z84XOTH3PHLkSJ577jkcx5s9v/zyy3KM",
        "++/Psiyv36PWpnjuwgIUY9p//3J8uy55eXkcPXqUXr16sWvXLho1asSXG7+MeR/Ecx8zZjSDBmWyYsUK3n9/PsXFxdx7773e/esaq1bl0Lt3H2699TYSEhIo",
        "KMjn1Vdf9ZS2rnHlhCvJzMzks88+4/3336e0tIT//u//9tonUolPIePIc+FVu8hwwKmHxkI9bFI1MSucffGF7du3k5uby4TsCQDs27+PqqoqLrnkkqiPr3ol",
        "qG07HDp0iFAoRMeOHT3/s6F77h1N48iRI5SWltKhQ/to9oYdnSG0JWJF2LN79zEKIX7AerOSY5VCfGCpsLCQ0tJSemb0lBkLwWBQtvXIkSNUVlXSoUOHmHsW",
        "hEIhKaxFlkd8VkVBQT6aptG9e3daNG9BXl4excXFHDl8hC5dutCmTRs2b96MaZqkpKQwePAQPvjgA5YuW0pBQT7hcFjO3EQQuaSkhDVr1vDss88C0Kdvn5j7",
        "c12H4uJiEhokxKTJpqWlSbeSmLnV1C/iXgOBAKZpUlFRzooVK3j66acB6Nu3LwAVFeUkJSXJ9gWDQZKTkj3B57gcOXI0+iw9S8lxXaqqqjAMnaNHj1BZWcnF",
        "F1+MaZrSrx0MBjl69CihUIhLLrnEi4f4+tWyLWzLE8RVVVUsX76c5557Dtd16devn1xIWFpayooVK/jHPzzB2Ldv32PGr3DjVFZWkZKS4ll40cyW5OSG8jlW",
        "x068vvMEvCn7T8Rn/OcWLqlwOIxlWdKa9R8jYiD79u8jHA7To0cPGWcQFhhAYmISQ4YMZeHChSxdtpT8/HzpDhXnMXSDyspKln++nGeffZZwOEzv3r05fPgw",
        "lmXRo0eP6syp6D9/GqyXjOC50hzHiaZ0VmeB+d85v//dcWzWrVtHv3796NmzJ/n5+ZSVl9XoisnMymLe+/NYtmwZ+fn5VFRUVE+sNI0rrriCdevW8eijjzJr",
        "1kO89tpr7N69G8d1SU5KJisri7lz50a/X0BlZaXsy5o43sTRiT5/x/EmnfV5BXS9VQoiIOZHzIwAPvroI9q2bUvffv1wHZfFixczePBgBg3KJDk5meTkhvTv",
        "359GjRrhug4ffvghAwYMoH///iQnN6RFixZcNXEipmmybNkyBg4cRL9+/UhOTqJjxw5cddVVrF+3jv37D0izH44dsIA0zf3/F8f6qays5OOPP6Z///4MGTKE",
        "hg0bkpSUxIABA2nSuAkRK8LHH3/MgAEDGDhgIImJiTRt2pSJV00kEPCEs6ZpdOnShQYNEqMWkh6TuldZVUVBQQFZWZns2rXTEwSGzvbt2xk0aBCGYbBjxw5s",
        "xyYUClFZVUmzZs0wDZPGjZswdepU6VJo27Ydt9x6C+3atwOgyUVNSExMpKiwqDrVNBrkPnLkCJ06dqJD+w4kJSZx2WWX0bZtW8CzhvyWQrwiE7Rq3YqbbrqJ",
        "Vq1aEwgEaNa8GQ0aNKCwsJBAIMC+fftp2bKlZ8o3bMjgwYPp2LFD9fhwbD7++GOysrLIzMwksUED2rRpw6RJ15CYmMTSZUvp378//fv3JxgI0qJ5C668cgLB",
        "YIBlS5cxePBgBg8eQlJSMklJyQwaOIjUlFQ6dOzATTfdRIsWLQgGgzRt2pSEhAQOHTpE8+YtuOOOO2jXvh2GbnBR06YkJydTWFgYc29uNEnCcV32799PixYt",
        "aNu2HQ0aNGDYsOF07Ngx5lhAZteZpsHUqVO5554fktiggXwXqsebJt10fitHxuS06ngGeHGoRYsWkZWVxZChQ2iY3JDExEQyMzNJaZhCeUU5kUjEe94NGtCy",
        "ZUuuv36aVFLt2rXj5ptvpmXLlvI5JScnU1xcTMSKsGjRIi4dcCmZgzJpmNyQhskNyRyUKV1Q3j2ZchGqpml0v6Q7iQ0akBBMOHbSJVKno/e8Zs1qmjdvzoCB",
        "A8jJyYlJexbK3nW9lNOWLVoSDAZp0aI5N998k3QLiioIjRs3pmHDhjIOlpCQgOu4hEIhwuEwTS5qQiBg0rJlC6ZPn+EpxDqkmIqJxsyZM7jrrrtISEioUcbV",
        "B+q9+8iIuoZsu3p2pJsG+w/sZ/369Vxx+RVs+mYTq3JWUVlZyWWXDWfs2LFUVlayc+cO8vPzAVixYkX075eRnZ1NZWUl69atwzAMVq1aRVlZGVdccTmTJ0+m",
        "uNhLSf3ss8+kH1YMVM8PbMkVqZbtpWYapiHdOmIGiKERCAbkvQSDQVauXCmvNWr0KCorKtmxYwfbt28HYPnnywmFQgwZPJiJEydSUlLChg0bcF2XXbt2snTp",
        "UrInZHPllVfy7zn/ZvOmzTI/XCweysvL44orrmDp0qXy2t988w2DMgeRn5fv+bVtB0fzfPhXXH4FDz74IPkF+Sz5cAnp6enohs6hQ4fYvn0706dNJ7lhMsVF",
        "xXz88cds3LhBur1EjOWzzz6jcePG3HzzzVRWVrJixQqWLVvG5ZdfLtP8dN2QbhTHiqCbhkwn1jSNI4ePkJ+fz8yZM0lJSeHIkSN88uknbNy4kUgkwhdf5NCs",
        "WTPuuOMOOWtfsmQpl19+uZwprl69mnA4zLBhw5g4cSKFhYV8+eWXWJZFzqocKsorGDFiBBMmTKCkpITc3Fwcx2XlypVUVlYybNgwRo8eTXl5Obt37yYvL48j",
        "h49QsKOAGTNmkJycLNcBrF27lsTERAoKCph2/TSSkpIoLy9j6dKlfPXVV9F6RNUuP+EaWrt2Lc2bN+e222+jssLrq8WLFzNy5EhvfOs6a9eupVv3blw54Uo+",
        "+GBBje+GeB80TZMrah3hJotOoIR1kZubS6/evRg1ajRLly6Jud9x48ZRVlrGrl072bVrF+XlZbz11ltkZ2eTlZnFrl27+Oijj2jcuDGu63L06BF27tzJtGnX",
        "06hRGsXFRXz2+Wds3LgBx3b44oscCgsLyc72xmlZWRm7du1i8+ZNmIYZTSf24kMHDx7k448/ZszoMUzInsDcuXPJzc3Fsi1PgEdL3Ij79RRchK+++orOnTuz",
        "fft2mZUo4lvgWVPvvPMOo0ePJjMzk4KCAhYv/pBJkyZ5csXQ+eKLL7jxxhtlijdAaWkpmzdvYtGiRfz73/9m5MiRDBs6jJ07d7B48WKuvPIquS5ExMe8BAjP",
        "wxCxIjKBQLoyHUcqIZkFFq3lVh/jClrW0GH1oyU+RMaFv7NMw/SEWVzHBcwA4XA4pgaSMK/FqlBRGsONCjB/YNgfyBL+TTHbEi8YHOvy8K8+FqmZ4vyapkuf",
        "rmi/OD/EBl/taCE08GIm1Vkrbsx1/NcTK1vFC2aaZozbR6ytAGQ+vzDdTcOUi/0cx8EwDemHFgJEZFfFt93ft9UvoiZfVi8grsecR8xihQL1u/WEIvO7nERf",
        "Vhd30+U1/fGXgBkgYkViVgML/G0S9y3+LmbL0q/rO97/gvqvK55tTWPBdVzZj/62i/4R8Rbb9gKLYpGZaXrPTpxTuIfEtfwzfjEO48eFv7xJ/DOJP8afFizu",
        "0/83obhFf/nHmz8LULwj8e4duUo52tb4jCnRL2JM+PtIXE9k8YRCIQIBU75H4FlAok2mYXLnnXfKSUxNq7PFsWKciHEv3k/DMPjxj3/MG2+8we7du+W727Zt",
        "O+644w5ef/11Nm/ZLOWOGLPiWYm4lMy+iwbnxfj3963//7Zly9hoTXKuPlBvLQWRhWFHA74WVo3HVVZWYkY7WZTDEII/vpOFn1U8VAsr5qEBsi6NYegQ/V20",
        "xz/wxPHVfnU3mpbmYDuxQlUIKFHUL94n7A8cC0Gp4+X/u2KWbRryhTNNA8uyiTgRef2EhAQvcI4WU0BQj/ry/e30Kw03mjLpKRg7mmZaPbil0HXdqAvCl/2j",
        "a76+iGaN+MocCMFm+1xvoj+kULCtGGEnBL/MQrE9Ze5G71t8X8zItGj2laPHZqxFIhaGacRkpAQCAW8GGn2BxYvpd2cJ4SUFthG9TydWeYh+0XSNoBn0hJeh",
        "y7FlGDqa6QVlXdeVFlE4HMaIfi5XF8cJDg1NKsFgMCjHvqbp4NpSwPuFqUh1rO1dsrFlppOXuaUD3vON2BEpdIUg85eNEWNG9K9fkcenWvr7Vbwf4r7EsxX3",
        "60e8vyL5w3FdTF2TExrXcdFMg6QGCdIt/Nmnn8l+iH8/BSL7SdyDGKupqamkpqbSsWNHiouLCYVCpKam0v2S7oTDYQ4dOiT74ZjSOyJrKvoui/v2FHp1kUO/",
        "leO6LqZu4mjVssZ/7/WJemkp+IkfQDWtZRCCQFgH4kH6Z1j+GZy/IqN/5ioCXiLTA7xAo5jx+WckYpYuBoeYXftncqK9/t/FugIxs4dYYeO/byBm5ibO4Z+9",
        "CMEhApmyn3xWjvBR+2db/r8D0VIDulRux5u9i/7yBz/FZwK/NSRmyGJGFT/jjp+VBoPB6KzOm4UFzIDMGoqfYcaPAfF/oQDEzEy0XyqbOMtCtMNv5fnHkt/y",
        "0jSvPEPEisjSDOLZC0tAnNdvjTrRxAKhhMXM1Z9GKfrRf2/+9oq2yCyeOEvAT033KPpGXDt+vMrxEPXJi1lt/DPyn0/MskXb/Ra5uLY/ZdR/D8JiEhMR0cey",
        "aKDv2XTr1p1p06dxYP8B5s2bx86dO6sVV5xSiL93f/+Ie83I6CVXdGuaRnFxMXn5eSz/fDmHjxyWVmAwGASIGX9+2WJFS7qIcS1icn4FKTKi/P0evw6rvlDv",
        "lUJtMwD/32pysYi/xyx08glFQbzp5jd/azLJgRhBEy/Q40sAxw9sfzvjXVA1vXQn2y/i+2Lw15S37Se+nyBWOPrLOp/o2rUhFKf/3KJ/4p+Dvx3+4+NdFzUJ",
        "ztrw90l8Ndnaxoz/b/H36++X+HaK44QiE/+vTYnVphChOmXUf68Cv/KrDX8/xh8f/6xrcivVZAnEu5xqoib3mX8WX5O70X/u2q7ht+zir1dTX9TkUozvh9qe",
        "u2iPn/jx4/+uHZ+67rPejmfB1OdS4fXWfXQqSIEc9zBFJgL4tHjcMcd8xycI5Xfj/ZW+Gb78rJYBerx2+o+PySapw8xBvFC15U3XpAiPd73aFEJt1HT/wprx",
        "n+dE6z2OaYd+rAD2Z6GdDELo1fhy1jBjq2kcyevWohDE/+Nn6zWNoRiBV8OYOV7fn4wyPN7544WlaK9/TPpLZ9Q2RmtCPJf4e47/CcQohPifx/TraYyZmv5/",
        "qghrt6bxUdN4OJnxWV8VApwDSuF4nXsqD/tkjz2Z4453TPzD/jZMw9oWysW4n6Izo9oEYW3IQOsJ+j3eyvF/vzYl7T9vbW043iy0roj41JkiXrDWlZpmpuLc",
        "eg3Cprb41slMSPycaEwe71ynM57j77e2Zxp/P3W95omU78ly3PflBMK9JotQ/P9UrvNdUn/VleI7J1641/T7uURNbpPTEea1WRunS239ezzFWdtaj+OdT6E4",
        "GZRSqCPxZvV3qeVF1svxqEt7RMaW43qLe+Jndq5T7WqRAfuon72mILloa22C2H++430mr1dDPx9PyDu2461G9vVXIBCocSZ6jIvQJ1j9bRKzeLFqXteO3Wfg",
        "ZAKIog1e+Q09Zs8If8E8fzzBjbP8RE0j//fF6mu/0qitT/1t+S4USfzzq22M1vT5yX52Km05UfvOJDW5reP/1ReUUlDUSE0CzTB0pkyZQvt27WXwzx94dR1v",
        "gVq8X/1U3Xxn0i0oyogIweg43upqIchPpU1efrsnhPv168dvH3jA2+LSiH4ujjvJ9osVuP4UZkM3CASqvbqiAq73eYCAGZACXJYwj26eA5CUlBRz/rS0dG67",
        "7baYFfdnwvWlOH+p9zEFxXfHMSl9Rqw/tEWLllx88cUsXOhtZnLZiBGMumKUd7zrba0YsSLYls2jjz4aszDwbBAIBLj00ku59NJLueiiiwDYtGkTn376KQcP",
        "HjipLB5/ujMgU1bFqlZBbZlMtZ3X0QHXpkP7Dtxxxx0y48i/MCwvL4+XX34Jx3W5qMlFTJiQTbt27XFdrzDc+++/763TMQ2ysyfSs2dPLNviy41fsnjxYkKh",
        "EEVFhSQmJtKrdy9yc3NjMriOF/tRXLgopaCoEU2PTS80dIOsrCxWrVpFRWUF4Am3isoKHn300WNSeXWxDeh3IHD8rg//9SZPnkzr1q1ZuHAheXl5NGjQgJGX",
        "j6Rfv74sXvwhuPZJpdfKtSxOtSIwjNhNcYQrCI5Vrsc7/86dO/jNb38T81mL5i248847WbduHZGIRXp6Ot/7/vdYu3Ytc+fORdcNBg8eTIMG3j4OU6dOJSk5",
        "iccff5zk5GSuu24KU6ZM4a233sKyovsIDMokNzf3JHpTcaGj3EcKifAti3+Gb2GQYRhkZGSwceMGb1vRqLtE7Lsr8upljMGx5aIeqI4z+Pem1nRN7sENsZk3",
        "ula91y0Qs7e0cAeJNnupotXKS9c0Bg0cRK9evfi//3uDb775xtu7uLSEuXPnsmjRouq1BD4l4r+ev/yIUDT+BVCRSATL9hY5RiLV5Tv89yAXLWnV+2eLY8T9",
        "yJX0PgUzceJV5OXlsX7DenRdZ8SIEezds5dFixZRWFjE0cKjzF8wn0OHD9G4cWO6de/G3DlzKS8vY9++fbz77ntkZGTQvLlXMn7Tpk20bNmSJo2byPvxWz8K",
        "hR9lKShOSCAQoHXr1lRWVlJaWiYXx9lW9WYxIj/dv0Jc7KGs6wa7du1ixIgRlJWV8cyzzzBp0jWAt5/tuHHjKCoq4u9//zuBgEnv3n0YPnw4TZs2paysjJUr",
        "V/LZZ95uaa7reNVtDZP8/HyuuOJyysrKmT17tiw74DougwYNZNOmTRw+fKR61zq3uoaNKDdtBkx6ZfRi+PDhtGjRgtLSUlatWiWvJ+jbrx8jLhtBSkoK+/fv",
        "Z9eunQTMgOdGiq7e7d27NyNGXCb3PP58+eesX7cO23a48caZNG3alKeffppQOHTMqm6xXqJbj0to16693HPaMHR69OjBwoULPYWqOTH30LRpU3RNp7i4WJ5v",
        "9+7dFBUV0alTJ/bv3+ftYrd3Lx07duTI0SPeeWsoNaFQgFIKCh+1rQ51XJdWrVpx4MB+KXSB6qJ6vlXUjk5s+QTdoGPHDoTDYZ555hmqqqoAzxXTvVt3bMfm",
        "qaeekjWB+vbrF60M+gFffvklrVu3ZurUqTRs2JDFixfjODamYdK5c2eqqqp49tnnZH0hb+cum6SkJJo3b8HGjV9Gd8jSY0qUaLoGjlcvqnfv3lx99dXMnz8/",
        "OqNuwZQp15GSksIHHyzAcV369e3H1Vdfzfvz3mfjxo00bdqUq666yuufqDDv378/I0eO5P3358k9j6fPmE55WTmbt2w+pga/KCsST2ZmJps2beLo0aNoukZS",
        "UjJp6WmEQiFmzJhBp06dZJXWVTmroju8OSQnJ8vvNGjQgFAoROMmjYlELAIBkwMHDtCyZcvqjCZdxRIUNaOUgqJGZImIaKmMhikNKS0ti/GRa5ongB544IHq",
        "Xddsm6effpp9+/d5K0GjbqSFCxfKEt+Gbsg9eOe/P18qFNM0GTtmLBs2bmDtWm9/3bz8PBYsWMD06dO9/bIPHcIwDKqqqli8eHFMwTJN1zAwaBDdc6CiokLW",
        "vYlEImj40jmjhQLHjRvHmjVr5PW2btvG/PnzmTFjBqtWreLo0SOMHTuW9evWsXrNagD27N3DF6u/oG3btmiaV7RN7BG+dds2HNshLy+PtWvX0qtXL7Zu3cJr",
        "r70WU/OmplW6KSkpdO7cmZdffkm6oZKTk3Adl/HjxzNv3jzefPNNLrnkEiZPmUxJSQlbt26luKiY7OxsFiyYD8CYMWPllpOC8vJyWrduLRVBfPVY0X8KhVIK",
        "ihqJz0xJSEiIEcB6NFOmsrKShx95GDi2UBqGF3CuqqqSWxw6rhutfOpQVVXlbRWpedVOxR7VWzZvAapdJHl5eUSsCB06dODQoUPYtrdBkGVXFwsUtXQc3VMG",
        "ruvSMKWhrFQpUjb9LpNmzZrTsGFDWZNf5Prn5+cTjoTlDngNGzZky5atUoCKYn/CUmrWrBlJiUnMnDkzpg81TSMvP09uwxizotVXgVdwySWXEAqF2L17t/d9",
        "vTr1dOHChWzbto1AIEBubi59+/ahZ8+e5Obm8tprr3H1pKv54Q9/REVFOR9+uISUlBQqKyulNWJZllSWmq4RCYcxzQAKRTxKKSgk8bNGf4XPqsoqkpIS63be",
        "Gurv1LQHr8CriFqduw9ecT1ZpdKJLUImFI3chF7zdoJr3aq1rMIZXwBP+NTFBk6iyKFor2lUC36//99f7TViRaKBZq/o3wsvvCA3SxLH11T0ML44nPh78+bN",
        "KSz0tgYV1yktLQPAML01DcJVVlJSQnp6Y3RD58CBA8yePVsG823HJjs7my+++EL2j65724kKi4xo5U+FIh6VfaQ4LiKDpry8XLokDN2IWWlbE9JicN0aA5ox",
        "ZbujxxQWFlJZWUnHTh3lVpQAF198Ma7rbWMZX7rCv1pXbE6vaTrLly+nS9cu3lajpkEkYsnjxJaWRUXF8npiFi2uZ9kWBQUFFBYWEolEaNWqlRTUhu7tGmYa",
        "JrZtU1xcTEVlBZdcconnHotmZjl2de18seuWWAXu30dc0Lp1a/bvPwB4M3vTMKmqqmTHzh30uKRHdCc3HdM0aNy4CYcOHfIyneS+B1558e7duhMIBGIUVJMm",
        "jSktLfXcgXGLCxUKP0opKGrFvzvZvn37aNGiZY0VL08XIaxFnCArM4uMjAwaNEikc+cujBs3jpycHG/BWbQshNgv2I/h2+Rm/fr17Nyxk5tvvpmuXbvRoEED",
        "GjVqxIQJV/Jf//UDOXNetGgRgwcPJiMjg0AgyMUXX8zYsWNZs3oNhYWFhMNhcnJWkZWVRefOnQkGgrRr146hQ4dKC8iyIiz5cIm3N3RWFklJySQnJTNo0CBS",
        "U1MxdIPJkyfzwx/+UO4HXJNgTklJoaSkRPavCJ5/8p//0KNHD3r37k1CQgJ9+/Wjbdu2rF69GtM0mXjVRLp3605CQgKdO3fmyisnsGTJEsrLy6U10qhRGgcO",
        "HIjJEFMpqYqaUO4jhaTGiqrRdM4dO3bQoEED0ho1oqi42FtLYOgkJiby8KxoTCGa5um4Dk88/gTFxUUAcr1CTL19x45u/1i917PruuTk5FBeXs4VV1zOtdde",
        "S3FxEatWrWLlypVyQyGBEMrC6vDOHfWZWxFef/11BgwYwJgxY7jpppsoKy+jIL+AN998U+7IlZOTQ0VlBZePHMmkayZRGs3sEXs9G6bBhx8uwbJsrrvuOgLB",
        "AJu+2cTixYuZNn1a1GWly/NcNvwyssdnU1paSkFBgZytm6YpNwqC2DUPguTkZCzLiimD7rouW7dt46233mLUqCuYdM0k9u/bzyuvvML+A/vRNY1Dhw4xduxY",
        "0tPTKSkp4aOPP2bt2rXSTZWQ1ID27dszb968mIqx/rLhtT1/xYVHvd9kR3F2iN9cRdN0rrnmGgoLC1myZIl3jG9xm0DseCbOEYlYJCYmEo6Ej9n0RGzmEr9z",
        "GiDjGcFAkFAodEypaEGNhc2iAWqxEZKIK4gd5ayIhRkwpT9fXMu/o11Ni7uqN13XoluTRnfQM/QaYxZiZzHXdTCjaxr821z68ccD4jdIEjuZiWC4f+W4fxOl",
        "+BXVov0ZGb0YMmQIf/vb3zBM45jFgvL+lFJQoNxHiuPgF3KRSITly5fTv39/GjRo4O1H7a8eGk1fFesQhEAKBEys6Kw8fjtPIQD9G7OAp2RCoRCO7RCOhKUA",
        "lEXtXG8P5try7HVDj1EIdtQqiUS8ukz+eAUgFYJlWzEVYv3VKyMRC9vxhHo4HPa2YYzuJyzuRwhp27K92EPUf69pOqFQKGabyXhsx5aWg2HohMPVO9Zp0VXi",
        "dtSq8isEEcOIVwiGbsiV3pmZg/j0s09jFILgVIv4Kc5/olM9zfunuKDxl7gAr+xDtaWgsXfvXvLz82nbtq3cvFykenqVQs1jFmTZtiODvJZlR9cHVJd/EC4g",
        "QzcI+FIkDdOoVYACNS78qgkpaKPnE9/zF7MDCIfDQPWew47rrdgWwlUoEuHr1zTdq14aN+s3TRPDt1+xE1V+XkkPQ5YPqem+RAkQADPgnVuU/tYNHcM0cGzn",
        "mLZrmhdLEX3q+BRu48aNsSybb77+WsUQFCeFljVkuItc1OOCprxJCoVCcaGi3EcKhUKhkCiloFAoFAqJUgoKhUKhkCiloFAoFAqJUgoKhUKhkCiloFAoFAqJ",
        "UgoKhUKhkCiloFAoFAqJUgoKhUKhkCiloFAoFAqJUgoKhUKhkCiloFAoFAqJUgoKhUKhkCiloFAoFAqJUgoKhUKhkJhoLogtFNReCgqFQnFBYwJKGSgUCoUC",
        "UO4jhUKhUPhQSkGhUCgUEqUUFAqFQiFRSkGhUCgUEqUUFAqFQiFRSkGhUCgUEqUUFAqFQiFRSkGhUCgUEqUUFAqFQiFRSkGhUCgUEqUUFAqFQiFRSkGhUCgU",
        "EqUUFAqFQiFRSkGhUCgUEqUUFAqFQiFRSkGhUCgUEqUUFAqFQiFRSkGhUCgUEqUUFAqFQiFRSkGhUCgUEqUUFAqFQiFRSkGhUCgUEqUUFAqFQiFRSkGhUCgU",
        "EqUUFAqFQiFRSkGhUCgUEqUUFAqFQiFRSkGhUCgUEqUUFAqFQiFRSkGhUCgUEh3cs90GheKs4DourhM7/nVNq/H3eOKPO96xCsV3gRjPJxrXJ8I80w1TKBQK",
        "xXePpp+ZiYlyHykUPhxXWc6Kc5OaLIS6UCelEG8un4mGKBT1AeUGUpzL+K2Fuo7lOrmPHNeVF3QdN6Yhhm4QCoUIBgPyWNHA+FmYUCbi++qFvDD4rmbjju2g",
        "aRqarmHoBpZlYZomrut4f69hSuRvm6bp4NoAGLqOZVkYhh79GxA9VlkXim8bIT9d10XTNG882jamYcifNrFy1j8uT2WM1kkpCOHt2A6maWDbDqZp0qxZM/r2",
        "7UPnzl1IT09HixPybswL5/0tVrMpb9aFhBMVzmcKXdNxXEdONo4ePcq2bVv54ovVHD5yGADbsbEtm0DgxEPfdmwM3fC+43hjvX2H9ky8aiKDBg2kTZs2x/1+",
        "/Pg/X9HUe/ut47oOthP7vtiWzcGDB1mxYjnz53/A9u15cqIjJkSCU4k3aFlDh7pw6oNXKAbbdkhISGB89nh69+rN8uXLyc39isLCohgl4N2Ye8zvrk8wqBnX",
        "hcWZtgw1Ta+ebGgaTZs2pWu3rgwdMpQNGzawaNEiQqEQuqFj6Aau65z0mEtISOCeu+9i0qSrCRgmYtQe7w5OZTRrcT8VCj8uxFgK8RMOy7KYN+99nn76Gcor",
        "yqu/F+eNORnqrBQgGlvQDW659RZcx+Vf//oXZWWlAEQi1jGzsfgX0C8UlEJQnCnEi2AYOo7rkp6WzrXXXott27zxxhuEw2HpBvITPwYNXcd2vEnPn/74RwZc",
        "2l++KbbPLXqmUApBcTwc15UTDV3TsB3PGjA0DTuqLFavXstPf/pTrEgEV47NU5Otp2X3WZbN+PHjcR2X559/npLSEhzXxXFdDNOQv4t/Nd1kbX9TKOqKYehS",
        "IQAUFhXywosvYAZMxo8fTyAQwLajcYXjjMFIJAK43HP3XQy8tH/sNaIvowZn7J9CcTz06JgT487UdQytOh7rujBoQH9+/MN75HfcOoyu01IKXgyhL3PmzCEQ",
        "CJzOqRSKb51/v/dvMnplePGukzCng8EAnTp15OqrJwJKcCvqLxoghvTEiRPp1Kljnc91WkohMzOTFStWUFh4NCY2oFCcTWqb+RcWHmXVylVkZmbi2CeOJ1i2",
        "zZUTJhA01YRHUf9xXM9RFAwGuOaaa+p8ntNSCp06dWLz5s3SFFco6jOapvPNN9/QqVOnGjODxPob8c/QdQZlZmK7rowhKBT1FV2rtmb79etX5/OcVpmLtLQ0",
        "Dhw4gGlGTxPN6VYo6iOu63D48GEaNWqEaZrYTux4PcZycF2ZdmpcIOmlinMbFy+z80Tp0sfjtJSCruu4rqtcR4pzBtu20HUd27FPOl3vQllvoDg/0GtIWT0V",
        "zNMNnzmOrbKHFOcMIte7ttIsKk1acT6g63WPDJyxpYiq/pGivmPbTjR17+TGqiqJrTiXiE0+rbs8Pi33kaZ7dTYM3cBGxRM8s02PKY9wqviV65kqhavwEOM1",
        "EAjU2rex1kHUvRT97fx4GmJVbPV80I1mrehatU86puBl9Of5cf/nL2LsaniWguaKdcnf4eI1RSyO63pF03RD+aHrMSf7bE7XN1u/cHEcCyHaXeFGc13ELdqu",
        "G81317As66y19LvCcc6vWGjNy9RO3WJQSuEMYugGo0aN4r777sOpg5VwsghrQrk2Tp1TcXM60Rn1+eIY9fzMDk8//TQZGRl069aN7t0voW+fflw54UpeffVV",
        "rKigNAyj1vOcyP12su65s01+fj7dunWjsrJSflZdk809Z+7jTKN2XjuDuK4TLa9snFKQMia4GVXTNW2n5/gGrKaMeUUdEK6jhIQEcnNzASgqKmblqhzuv/8X",
        "VFZW8IP/77/Ociu/GyorK7FtG9uunsCJgnMXMqdlKRi6N5vwp/ddyOhRt1FtZqljOzG7I7mOG3U16XIVbk3BTdfx/ia+q0WPEfEciBbIsmx5fPw5HLXAMGaM",
        "nsx4NXSv6ur5MmN0HAdNO9YCaNSoEePHjWHq1Km88867APK+bSd25ffJ9EXN1ZCP/Z74TLwv4v/CdeX/Tvwx8dTk7oo/Nv69LC4u9nzvvne2pnL/58vzP1mU",
        "pXAGOd7g0TWNQEICEStCz549GT1qNI0aNaK4uJhPPvmEDRvWY9sOzVu1ZOjQoXTo0IGGKQ05fOgQixd/yJatW5gyZQqtW7fmb397CvDqqesBjR/e80M2b97M",
        "smXLiES8819xxeWkpzemsPAon3++nLVr135X3XDeECPQzvHZo+u66Lr3uvtLL3uKwpsblpaWeQIyGlv48MMPeeyxx9i1Zzdt27blv/6//+LqiROlEP3kk094",
        "4okn2L59O02bNmXChAnce++9aJrGwoULeeqpp8jLy6NVq1bccMMN3HjjjbJG2q9+9Ss0TWPQoEH87W9/Y9euXfTu3ZtZs2bRuXNnAH79618DcOmll/Liiy+y",
        "e/duunXrxiOPPEKnTp3krH7x4sU8/vjj7Nq1i/bt23PbbbcxefJkwFMWn3/+OU888QTbtm2jSZMmjB8/nlAoxD//+U+gevXvyy+/TGZmZo2lqS8klFI4gxxv",
        "EZ/jujhWhH59+zF27Fjeffcddu7cRevWrbnuuuuoqKhg85bNXHzxxRw9epTFixdjWRajRo1i8uTJ/PWvf+XLLzfSr18/mjdvwb79+9A0jebNW9CsWTPee+89",
        "QqEQ/fv3j57/XXbt2kWbNm2YPHky5eXlbNm65TvsDUV9wpv521HlUG396LpO4dEilixdyrz35zF16nXomsa///1vHnvsMR559FH69uvH5k2buOuuu0hPS2P4",
        "8OEsWLCAX/ziF/zkJz/h2muv5dChQyxbtgyAefPm8ctf/pJZs2YxcuRIcnNz+fnPf87+/fv5xS9+IRe9vvfee5imyeuvv47jONx55538/ve/5/nnnwc8hTV3",
        "7lxM02T27Nk4jsP3v/99HnnkEZ5//nk0TeOdd97hqaee4pFHHqFv375s3LiR//mf/6FJkyaMHDmSRYsWce+993LfffcxefJkDhw4wCeffMIdd9xBz549+eUv",
        "f8natWtJSkqq0Uq4EJWDUgrfEjVtPwowbtw45s6dS15ePq7rsH37djZs3EBGRgZbt27h008/BZBlGP7zn/8waNAgWrRowdZt2ygqKqRXr14cOLAf3TTo0aMH",
        "Bw8eZO/ePQQCJtnZ2cydO5eCggLC4TDbtm1j48aN9OnTRymFU8S/Yc+5j4amGbiuhWXZhEIhunTpgq4b6NE06olXX83PfvozLNvi0Ucf5eGHH2bokCE4rku/",
        "fv2YfO21zJkzhyFDhvDQQw8xZcoUbrvtNjRNIy0tja5duxKJRHj44Ye54YYbmDRpEpqmMWTIEH7+85/zi/vuY/qM6XTs0BHDNOl+SXcefPBB6TadOHEizz33",
        "XIww7tmzJ7/5zW8wDM81e9XEiTz7zDPYjoPrOvzhj3/k4VmzGDx4MK7rMnDgQKZMmcL8+fMZMmQIDzzwANOmTeO2224DPFdZ165dvR7xWUs19th58dxPndNS",
        "CiKf2XHdmPr1ippp3ao1SUlJ3HTzTUTCERzXIRgI4rouO3bskP3YsWMnunXrRrt27WjSpAkAqamp6JrGunXr6dOnD0uXLsWyLDIyMli3bh0ALVq0JCkpiRkz",
        "ZkgT39uT2GXnzp1n89brBZquydjKyawB8QSPe1qrQ+sbum6iaRrBYFAGmm+55VbS09P44x//gKHrbN6yhcLCQn7wgx+g6zqO42BE65v17dOH/Px8jh49yrBh",
        "w+R5hQAtKCigsLCQwYMHx8Rjhg0bhu3YrMr5gnbtO3hreKKZXeK7aWlplJSUxJzTdV1ZW81xXVIbNaKkrBQX2LptG0ePHuWue+72XD4+8TNgwAB27txJaWkp",
        "w4cPl4rGcRxpqYggs+M4NVoJfi4kBaEshe8Q13UxDIMXX3iRbdu2YttOdNAbMpB85dUT6d+/P8uXL2fhwoUcOXKEn/3sZ2iahm07bNy4kZEjR9KyZUts26ZJ",
        "kyasX78e8Or6aJrGSy+9xPa87V7w2XZiNqu/0LmQXu7aiPeZ//jHP2LGjBnccsst9OvXz1us57q8/PLLDBkyRB4nBGl+fj7gWbOxsQlNzuidqEIVgj0QCGBb",
        "trcBkqadVKD/GEEd9xMAXePlV14hc1Cmd17fNbdv3y6VijiXUPCirYZhEAwGY+7hQo8pnD9ToHOAwsKjlJaW0v2S7l4wT9cwTQPL8rK3kpISGTRoEAsWLODj",
        "jz+mYIfnAvLPmA4ePMiuXTvpmdGTjIwMtm/fTnFxMbbtUFRUTHl5OT0zesprarrmbfqtso8kp5JNcr4p0/iMHsdx6N+/P6NHj+bhhx8mEonQqVMnUlNTWbJk",
        "yTGuFdM0ad++PcnJyXz++ecy60cI27Zt29KwYUNWrVqFFl0Ep2kay5cvJyEhgT69+8h2nM6uc5qm0blzZ1JTU1m8eLGsYqv5FEPr1q1JTU1l5cqVUkn5CQaD",
        "mKZJVVVVjEK4EDOO/Cil8B1SUVHJ0qVL6d+/P8OGDiOxQQNSU1O59NJLadKkCaFQiEgkwkUXNfGCyM2aMWPGDAB0w/P7BgIB1q/fQI9LetCjRw82bNgQFfwu",
        "VVVVLP5wMf3792fw4MEkJCSQ1qgRAwYMlG4ohcfJLPwTx5yvc0Zd16V76N577yU3N5d58+ZhGAa/+tWv+L//+z9ee+01ioqK2L9/P2+88QYHDx4kGAzyy1/+",
        "kn/+85+88847FBUVkZeXx4MPPoht29x///289tprzJkzh8rKSlatWsUjjzzC9VOn0rVLF89i1vVa+7W2Wbr/eeiaRsAw+elPfsJb/3yT52fPpqi4mCNHjvDW",
        "W29x8OBBEhMT+dnPfsZrr73G22+/TVFREdu2bePhhx+mtLSUzp07E4lE+Oijj+SaBXH9C9lSOC33keM61bWPvsUVvOcKogJnMBhk1qyHsW1b+qT379/H3//+",
        "d75Y/QUVlRVcNvwyxo0bR2lpKfn5+ezevRtN03nrrbcYP348mVlZ7Nq1iyUfLiE9PR3HdjB0A9d1yM3NJTs7G8dx2Lx5E4ZuyL+tWb0GK2IxYsQIssdnU15e",
        "zo4dO6TJfyHjOm60/tHJzf7F7Pf8qXvkUV3yvjoD6eKLL+aaa67h8ccfJzs7m8mTJ9OwYUOeeeYZfv/739O0aVP69evH4MGDadq0Kddffz1JSUk888wzPPTQ",
        "Q7Ro0YLs7Gwsy2LKlCmkpKTw5JNPcv/999O8eXNuvfVWbr/9dqDajRoIBGKCyvFuHPHuiAWhmqYRMAwc20HDe99mTp9B4/TGPPfcszz2l7+Qnp7OgAEDGDhw",
        "IM2aNWPq1KkkJibyj3/8g1mzZtG0aVMmRtNqu3Xrxt13382jjz7KrFmzeOihh5gwYUJM7OFCRMsaOqzOdtKDDz7Igw8+qJRCFCF0/Iv6BGKWI2IH8Zu8WBFL",
        "lhYQMYD4wL2IETiOI18g74XR5blF4N91vJdeN3T5PfECXqiF9sTzefDBB/l/v/vdCRMjTENn2bKlGIZZZzdHfUIoAeHWEYJWID7zB9cjkUjM/uvxaZrHE57i",
        "erZty2Cx3+dvWZb83O/28eN369R0TfF7fDtra4OIi4jfxbVPdC/nAv6+dYFhwy7DrcOg1aN1ETmdUqsKD033VhpHIhFct3r1slAIenRGL9B9ATcv6FX9IooY",
        "gPi+V6TMjp4nOoN1HZn1JRSB7cuu0Q1droYWwbYLVSH4OdnV9+ebX9kvdP3BV4EQ0H6BGy9o479TkxCNF7amaUbfCTdG+PsVhb9t/n6vaUW5sHT8mUTx7fTH",
        "EMS1hILxKyL//ZzLCsHP6bq+dKUMzhxCAOtR4S5mI47rCetIJCIDc+KnaZoxikIIc8PQPTNZ12QZDNM0pFC3o5sbWZaNaZiee8nw/MOi5IVpmF4w2/CsEtM0",
        "L/gieoZuyBLaJ8ITKudHf/mFrr+MRHwZivgZ+clWEo0X5PFlI4QSqq3sRfx3aprFx9+LP5Mo/n6EsvB/x/+Z/3yRSCSmX85VYoq+y3s/9fHr23mtboPfNDzB",
        "ZxrebOBCnon6791xXXBtqSBq6hdxjPi7X1D5lYtwM8l66b5z6YaOZVvoUYvBiKa3GqaBZUcVUPTnhe7i03RPkJyspWDbLq4LjuNinOPj2i/s/TPlmv4ef9yp",
        "nh+OnXUfbyFgfLpo/HG1netU2hB/ff/fhJVxKvdbP/HJH9vB1TSqS2eeQoHO+JOdCo7t+bYty8Jx7AtaISjqP14sx/AWY+m1l4YWGIaOZdnoenU8SKGobwhv",
        "hAgCOK5XyLCunJYT7ejRI6Snp8tGxTRUVU1V1DM0XaNx4yYUFh49KatJ07ysMR1wXLV/haJ+IqomG9HhqWsae/ftrfP5Tksp5OcX0K1bN0zzxLMuheJs4Rfm",
        "Xbp28epOncSkxXZsVq9egwvyhVMo6iueleD9vnZN3asin5ZSyMnJYfDgwTRpclH1CaMvoMikUSi+K/x7Rji2I7O29KirKD0tnWFDh7FmzeqTOp+uacydO5dQ",
        "2IvJODUEKRWK+oJnzXo1u95+++06n+e0JPehw4fIzf2Ka66Z5C2ecrxsGJkX79tQRqH4tjFNIybNVxCJRDB0g8lTJrNhwwYOHDx43KCiGLeO61JQUMD8+fMB",
        "fKnFulIMinqJ7bi89+577N6zu87nOO2d1+bPX4Bl2dx62600adLEWyylezn3hqGr4LPiO0Ok7oqaUoL09DRuuukmXMdl0aJFcmN6sRNebbiOSyQS4cknn2TV",
        "F6tjgnfnS0674vxB12DNmjX87W9/k7sw1gUta+hQ91Szj8TKUP+irAlXTqBnz558kfMFX3/9NUeOHCEUDtW5YQpFXXAdr/y4aQZo2rQp3bp1Y9CgQWza9A3z",
        "5y/Atq3qva6j47gm/PthOLZDUmIiP/7xj5g48SoMPXYFuUJxtnGB9/49h6eeeopIOITjeu4kLyX11BYn10kpyIbEvVStWraiV+9edOvajaSkJBISEqovpGvH",
        "HO+fpXmb3dfNJNc18ZKe3vcVZxfHPf7M/WQRi5gOHTrEzp07WbNmNYcPH8F2ql2bYjzCye2toLnece3atWPSpEkMuHQAbdu2Pe22+jHO8YSNY9YJfMf60j4P",
        "XNU17W8t/x93f6FQiEOHDrEqZxUfLPiA7du3xx4vn8ep9csZVQo11fc50RaV/plWXfPA/dc9ne8r6gdnaj2AvyaXKBgIxJQRPxX3plAo8O0kUpzr6yDO9nt0",
        "rvffiYiXc6Zh4kTHdyRinbFJxWkt4YtXCKKxhm5gY8tl48cz0eH0H+bZ/r6ifiFmVJZjxZQFEZMYv5VwKogaUkBMwcIzlUxxvsXf1Ht1Zompa6ZpslIBeFbm",
        "8dyhp8IZW9ftuC6O7WCahlfuoobia37F4Z9VnCnloLiwkeMoOol3HTemYq1/PNbl5REBavAsBTmGDTV+FadPvKUVvzHWCSfXZ8h4PaPFPsSWkUIh1GROnm0T",
        "U3H+Ej/hcPTYndPqOvkQloDt880qBXAsqk9Oj/j+O97EJb5OGhw/ceJUOLNKIa5BNVkFCsW3TU0vTPzvp4IY12rNjeJC4DspC6hmEIrzgZrcoX7UOFecD6hc",
        "TIVCoVBIzLqmoyoUFzrKMlDUJ85U9pqyFBQKhUIhUUpBoVAoFBKlFBQKhUIhUUpBoVAoFJJzfafqU8M9S0F17QQByTPVrhNdR6FQfHty4Fx//6L98v8Dddc5",
        "vgSGBB4AAAAASUVORK5CYII="
    ]
    B64Full := ""
    for _, Part in B64Parts
        B64Full .= Part

    if WriteBase64ToFile(B64Full, ReferenceImage) {
        if IsSet(PreviewBox)
            RefreshImagePreview("Built-in default (Disconnected / Error 769)")
        if ShowNotification
            TrayTip("Restored built-in default detection image!", "EricMudkip ACX Rejoiner", 1)
    }
}

RefreshImagePreview(StatusLabel) {
    global ReferenceImage, PreviewBox, ImgPathLabel
    try {
        if FileExist(ReferenceImage)
            PreviewBox.Value := "*w210 *h114 " ReferenceImage
        ImgPathLabel.Value := "Active Image: " StatusLabel
    }
}

WriteBase64ToFile(B64Str, OutFile) {
    try {
        DllCall("crypt32\CryptStringToBinaryW", "Str", B64Str, "UInt", 0, "UInt", 1, "Ptr", 0, "UInt*", &BufSize := 0, "Ptr", 0, "Ptr", 0)
        if (BufSize <= 0)
            return false
        Buf := Buffer(BufSize)
        if !DllCall("crypt32\CryptStringToBinaryW", "Str", B64Str, "UInt", 0, "UInt", 1, "Ptr", Buf, "UInt*", &BufSize, "Ptr", 0, "Ptr", 0)
            return false
        FileObj := FileOpen(OutFile, "w")
        FileObj.RawWrite(Buf, BufSize)
        FileObj.Close()
        return true
    } catch {
        return false
    }
}

; ==============================================================================
; Core Monitoring & Rejoin Functions
; ==============================================================================
SaveConfiguration(ShowMsg := false) {
    global ConfigFile, LinkInput, ChkDirect, ChkCloseFirst, ChkRetryClosed, ChkCriticalPopup, ChkReconnectBtn, ChkUseImg, EdtVariation
    IniWrite(Trim(LinkInput.Value), ConfigFile, "Settings", "ServerLink")
    IniWrite(ChkDirect.Value, ConfigFile, "Settings", "UseDirectProtocol")
    IniWrite(ChkCloseFirst.Value, ConfigFile, "Settings", "CloseRobloxFirst")
    IniWrite(ChkRetryClosed.Value, ConfigFile, "Settings", "RetryIfRobloxClosed")
    IniWrite(ChkCriticalPopup.Value, ConfigFile, "Settings", "HandleCriticalPopup")
    IniWrite(ChkReconnectBtn.Value, ConfigFile, "Settings", "ClickReconnectIfNoLink")
    IniWrite(ChkUseImg.Value, ConfigFile, "Settings", "UseImageSearch")
    IniWrite(EdtVariation.Value, ConfigFile, "Settings", "ImageVariation")
    if ShowMsg
        TrayTip("Settings saved to rejoin_settings.ini", "EricMudkip ACX Rejoiner", 1)
}

ToggleMonitoring() {
    global IsMonitoring, CheckIntervalMs, StatusText, BtnToggle, LastNoWindowTick
    SaveConfiguration(false)
    IsMonitoring := !IsMonitoring
    if IsMonitoring {
        LastNoWindowTick := 0
        StatusText.Value := "Monitoring Roblox in background..."
        StatusText.Opt("cGreen")
        BtnToggle.Text := "Stop Monitoring (F1)"
        SetTimer(MonitorRobloxRoutine, CheckIntervalMs)
        MonitorRobloxRoutine()
    } else {
        StatusText.Value := "Paused (Press F1 to resume)"
        StatusText.Opt("cRed")
        BtnToggle.Text := "Start Monitoring (F1)"
        SetTimer(MonitorRobloxRoutine, 0)
    }
}

MonitorRobloxRoutine() {
    global IsMonitoring, LastRejoinTick, LastNoWindowTick, ConsecutiveLaunchFailures, CriticalPopupCount
    global RejoinCooldownMs, NoWindowRetryMs, TargetWindow, ReferenceImage, LastOcrText, StatusText
    global ChkUseImg, EdtVariation, ChkRetryClosed, ChkCriticalPopup

    if !IsMonitoring
        return

    ; 1. Check for standalone Roblox error dialog windows (#32770 title "Roblox") fromBeta or Launcher
    PopupHwnd := WinExist("Roblox ahk_class #32770")
    if (PopupHwnd && ChkCriticalPopup.Value) {
        HandleCriticalSettingsPopup(PopupHwnd, "Windows Dialog #32770")
        return
    }

    Hwnd := WinExist(TargetWindow)

    ; 2. What if Roblox is NOT open at all?
    if !Hwnd {
        ; Wait a shorter retry window (20s) when Roblox is completely closed/missing
        if (LastRejoinTick > 0 && (A_TickCount - LastRejoinTick < NoWindowRetryMs)) {
            WaitSec := Round((NoWindowRetryMs - (A_TickCount - LastRejoinTick)) / 1000)
            LastOcrText.Value := "Waiting for Roblox to open (" WaitSec "s before retry)..."
            return
        }

        if ChkRetryClosed.Value {
            if (LastNoWindowTick = 0) {
                LastNoWindowTick := A_TickCount
                LastOcrText.Value := "Roblox not open. Launching in 5s if still closed..."
                return
            }
            if (A_TickCount - LastNoWindowTick >= 4500) {
                LastNoWindowTick := 0
                ConsecutiveLaunchFailures += 1
                UseBackupBrowser := (ConsecutiveLaunchFailures >= 2)
                TriggerRejoin(UseBackupBrowser ? "Roblox Not Open (Backup Browser Launch)" : "Roblox Not Open (Auto-Retry)", UseBackupBrowser)
                return
            }
        } else {
            LastOcrText.Value := "Roblox window not detected (Auto-retry when closed is unchecked)."
        }
        return
    }

    ; Reset the no-window timer since a Roblox window exists
    LastNoWindowTick := 0

    ; Check the dimensions of the detected Roblox window
    WinGetPos(&WX, &WY, &WW, &WH, "ahk_id " Hwnd)
    IsSmallPopupWindow := (WW < 520 || WH < 320)

    ; If a small Roblox popup window is open (like the 355x155 "Failed to download or apply critical settings" box),
    ; do NOT wait for the full 35s cooldown—inspect it after just 6 seconds!
    ActiveCooldown := IsSmallPopupWindow ? 6000 : RejoinCooldownMs
    if (LastRejoinTick > 0 && (A_TickCount - LastRejoinTick < ActiveCooldown)) {
        RemainingSec := Round((ActiveCooldown - (A_TickCount - LastRejoinTick)) / 1000)
        LastOcrText.Value := "Cooldown active (" RemainingSec "s remaining while Roblox loads)..."
        return
    }

    ; 3. ImageSearch check using the built-in or user-replaced reference image
    if ChkUseImg.Value && FileExist(ReferenceImage) && WinActive("ahk_id " Hwnd) && !IsSmallPopupWindow {
        CoordMode("Pixel", "Window")
        VarTol := IsInteger(EdtVariation.Value) ? Clamp(Integer(EdtVariation.Value), 0, 255) : 50
        try {
            if ImageSearch(&FoundX, &FoundY, 0, 0, WW, WH, "*" VarTol " " ReferenceImage) {
                ConsecutiveLaunchFailures := 0
                CriticalPopupCount := 0
                LastOcrText.Value := "Detected disconnect prompt via ImageSearch!"
                TriggerRejoin("ImageSearch Match")
                return
            }
        }
    }

    ; 4. Background Windows OCR scan of the Roblox window (works even if unfocused)
    OcrText := CaptureAndOcrWindow(Hwnd)
    CleanPreview := RegExReplace(OcrText, "[\r\n]+", " ")
    if (StrLen(CleanPreview) > 95)
        CleanPreview := SubStr(CleanPreview, 1, 95) "..."
    LastOcrText.Value := "Last OCR: " (CleanPreview != "" ? CleanPreview : "(No text read)")

    ; 5. Check if OCR detected the "Failed to download or apply critical settings" startup error popup
    if ChkCriticalPopup.Value && RegExMatch(OcrText, "i)(critical\s*settings|check\s*your\s*internet|Failed\s*to\s*download|apply\s*critical)") {
        HandleCriticalSettingsPopup(Hwnd, "OCR Matched Critical Settings Error")
        return
    }

    ; If we have a normal full-sized Roblox window without startup errors, reset launch failure counters
    if !IsSmallPopupWindow
        ConsecutiveLaunchFailures := 0

    ; 6. Match the in-game disconnect overlay:
    ; "Disconnected", "Reconnect was unsuccessful. Please try again. (Error Code: 769)"
    if RegExMatch(OcrText, "i)(Disconnected|Reconnect\s+was\s+unsuccessful|Error\s*Code\s*:\s*769|Error\s*Code\s*:\s*\d+)") {
        CriticalPopupCount := 0
        TriggerRejoin("OCR Detected Disconnect Overlay")
    }
}

HandleCriticalSettingsPopup(PopupHwnd, DetectionSource) {
    global CriticalPopupCount, LastRejoinTick, StatusText, LastOcrText
    CriticalPopupCount += 1

    ; First attempt: click the "Retry" button inside the popup dialog
    if (CriticalPopupCount = 1) {
        StatusText.Value := "Critical settings popup detected — clicking Retry..."
        StatusText.Opt("cBlue")
        LastOcrText.Value := "Action: Clicked 'Retry' on critical settings popup (" DetectionSource ")"
        try {
            ControlClick("Button1", "ahk_id " PopupHwnd, , "Left", 1, "NA")
        }
        try {
            ControlSend("{Enter}", , "ahk_id " PopupHwnd)
        }
        LastRejoinTick := A_TickCount - (RejoinCooldownMs - 8000) ; Check again in ~8 seconds
        return
    }

    ; Second+ attempt: close the stuck popup and re-launch the server link (using backup mode if repeated)
    CriticalPopupCount := 0
    try WinClose("ahk_id " PopupHwnd)
    Sleep(500)
    TriggerRejoin("Critical Settings Popup Retry Failed — Re-launching Link", true)
}

Clamp(Val, Low, High) {
    return (Val < Low) ? Low : (Val > High) ? High : Val
}

TriggerRejoin(Reason := "Detected", ForceBrowserBackup := false) {
    global LastRejoinTick, LinkInput, ChkDirect, ChkCloseFirst, ChkReconnectBtn, TargetWindow, StatusText
    SaveConfiguration(false)
    ServerUrl := Trim(LinkInput.Value)

    if (ServerUrl = "") {
        if ChkReconnectBtn.Value && WinExist(TargetWindow) {
            StatusText.Value := "Clicking in-game Reconnect button (" Reason ")"
            ClickInGameReconnectButton(WinExist(TargetWindow))
            LastRejoinTick := A_TickCount
        } else {
            StatusText.Value := "Please enter a Private Server / Game Link first!"
            StatusText.Opt("cRed")
        }
        return
    }

    ; Automatically prepend https://www.roblox.com/games/ if the user pasted a partial link starting with PlaceId
    ServerUrl := NormalizeServerUrl(ServerUrl)

    LastRejoinTick := A_TickCount
    StatusText.Value := "Rejoining server (" Reason ")..."
    StatusText.Opt("cBlue")

    ; Close any stuck Roblox error popup or disconnected Roblox client first
    if WinExist("Roblox ahk_class #32770") {
        try WinClose("Roblox ahk_class #32770")
    }
    if ChkCloseFirst.Value && WinExist(TargetWindow) {
        WinClose(TargetWindow)
        if !WinWaitClose(TargetWindow, "", 4) {
            try ProcessClose("RobloxPlayerBeta.exe")
        }
        Sleep(1000)
    }

    UseDirect := ChkDirect.Value && !ForceBrowserBackup
    LaunchTarget := UseDirect ? BuildRobloxLaunchTarget(ServerUrl) : ServerUrl
    try {
        Run(LaunchTarget)
    } catch {
        ; Fallback to raw URL in default browser if protocol launch fails
        Run(ServerUrl)
    }
}

NormalizeServerUrl(RawLink) {
    Clean := Trim(RawLink)
    ; If user pasted a partial path like "811370/Anime-Crusaders-X?privateServerLinkCode=..."
    if RegExMatch(Clean, "^\d+/[A-Za-z0-9_-]+") {
        return "https://www.roblox.com/games/" Clean
    }
    if RegExMatch(Clean, "i)^www\.roblox\.com/") {
        return "https://" Clean
    }
    if RegExMatch(Clean, "i)^roblox\.com/") {
        return "https://www." Clean
    }
    return Clean
}

BuildRobloxLaunchTarget(RawLink) {
    ; 1. If already a roblox:// protocol URI, return as-is
    if RegExMatch(RawLink, "i)^roblox://")
        return RawLink

    ; 2. Newer Roblox Private Server Share Link format:
    ;    https://www.roblox.com/share?code=<32-char-hex>&type=Server
    if RegExMatch(RawLink, "i)roblox\.com/share\?.*?code=([a-f0-9]+)", &Match) {
        return "roblox://navigation/share_links?code=" Match[1] "&type=Server"
    }

    ; 3. Classic Roblox Private Server Link format:
    ;    https://www.roblox.com/games/<PlaceId>/...?privateServerLinkCode=<LinkCode>
    if RegExMatch(RawLink, "i)(?:roblox\.com/games/|^)(\d+).*?privateServerLinkCode=([A-Za-z0-9_-]+)", &Match) {
        return "roblox://placeId=" Match[1] "&linkCode=" Match[2]
    }

    ; 4. Standard Roblox Game URL:
    ;    https://www.roblox.com/games/<PlaceId>/...
    if RegExMatch(RawLink, "i)(?:roblox\.com/games/|^)(\d+)", &Match) {
        return "roblox://placeId=" Match[1]
    }

    ; 5. Fallback to opening the user-supplied URL in the default browser
    return RawLink
}

ClickInGameReconnectButton(Hwnd) {
    WinGetClientPos(&CX, &CY, &CW, &CH, "ahk_id " Hwnd)
    if (CW > 0 && CH > 0) {
        TargetX := Round(CW * 0.56)
        TargetY := Round(CH * 0.57)
        PostMessage(0x0200, 0, (TargetY << 16) | (TargetX & 0xFFFF), , "ahk_id " Hwnd) ; WM_MOUSEMOVE
        Sleep(50)
        ControlClick("x" TargetX " y" TargetY, "ahk_id " Hwnd, , "Left", 1, "NA")
    }
}

CaptureAndOcrWindow(Hwnd) {
    global OcrScriptPath, TempCapturePath, TempTextPath
    try FileDelete(TempTextPath)
    Cmd := 'powershell.exe -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File "' OcrScriptPath '" -Hwnd ' Hwnd ' -OutPath "' TempCapturePath '" -TextOut "' TempTextPath '"'
    try {
        RunWait(Cmd, , "Hide")
        if FileExist(TempTextPath)
            return Trim(FileRead(TempTextPath, "UTF-8"))
    }
    return ""
}

InitOcrHelperScript() {
    global OcrScriptPath
    Lines := [
        'param([Int64]$Hwnd, [string]$OutPath, [string]$TextOut)',
        '$ErrorActionPreference = "SilentlyContinue"',
        'Add-Type -AssemblyName System.Drawing',
        '$cs = "using System; using System.Runtime.InteropServices; public class Win32Cap { [StructLayout(LayoutKind.Sequential)] public struct RECT { public int Left; public int Top; public int Right; public int Bottom; } [DllImport(""user32.dll"")] public static extern bool GetWindowRect(IntPtr hWnd, out RECT lpRect); [DllImport(""user32.dll"")] public static extern bool PrintWindow(IntPtr hWnd, IntPtr hdcBlt, uint nFlags); [DllImport(""user32.dll"")] public static extern bool IsIconic(IntPtr hWnd); }"',
        'Add-Type -TypeDefinition $cs',
        '$ptr = [IntPtr]$Hwnd',
        'if ([Win32Cap]::IsIconic($ptr)) { exit 0 }',
        '$rect = New-Object Win32Cap+RECT',
        'if (-not [Win32Cap]::GetWindowRect($ptr, [ref]$rect)) { exit 0 }',
        '$w = $rect.Right - $rect.Left',
        '$h = $rect.Bottom - $rect.Top',
        'if ($w -le 80 -or $h -le 60) { exit 0 }',
        '$bmp = New-Object System.Drawing.Bitmap($w, $h)',
        '$g = [System.Drawing.Graphics]::FromImage($bmp)',
        '$hdc = $g.GetHdc()',
        '$printed = [Win32Cap]::PrintWindow($ptr, $hdc, 2)',
        '$g.ReleaseHdc($hdc)',
        'if (-not $printed) { $g.CopyFromScreen($rect.Left, $rect.Top, 0, 0, $bmp.Size) }',
        '$g.Dispose()',
        'if ($w -lt 520 -or $h -lt 320) {',
        '    $bmp.Save($OutPath, [System.Drawing.Imaging.ImageFormat]::Png)',
        '    $bmp.Dispose()',
        '} else {',
        '    $cropX = [int]($w * 0.20)',
        '    $cropY = [int]($h * 0.20)',
        '    $cropW = [int]($w * 0.60)',
        '    $cropH = [int]($h * 0.60)',
        '    $cropRect = New-Object System.Drawing.Rectangle($cropX, $cropY, $cropW, $cropH)',
        '    $cropped = $bmp.Clone($cropRect, $bmp.PixelFormat)',
        '    $bmp.Dispose()',
        '    $cropped.Save($OutPath, [System.Drawing.Imaging.ImageFormat]::Png)',
        '    $cropped.Dispose()',
        '}',
        '$null = [Windows.Media.Ocr.OcrEngine, Windows.Foundation, ContentType = WindowsRuntime]',
        '$null = [Windows.Graphics.Imaging.BitmapDecoder, Windows.Foundation, ContentType = WindowsRuntime]',
        '$null = [Windows.Storage.StorageFile, Windows.Foundation, ContentType = WindowsRuntime]',
        'Add-Type -AssemblyName System.Runtime.WindowsRuntime',
        '$asTaskGeneric = ([System.WindowsRuntimeSystemExtensions].GetMethods() | Where-Object { $_.Name -eq "AsTask" -and $_.GetParameters().Count -eq 1 -and $_.GetParameters()[0].ParameterType.Name.StartsWith("IAsyncOperation") })[0]',
        'Function Await($WinRtTask, $ResultType) {',
        '    $asTask = $asTaskGeneric.MakeGenericMethod($ResultType)',
        '    $netTask = $asTask.Invoke($null, @($WinRtTask))',
        '    $netTask.Wait(-1) | Out-Null',
        '    return $netTask.Result',
        '}',
        '$storageFile = Await ([Windows.Storage.StorageFile]::GetFileFromPathAsync($OutPath)) ([Windows.Storage.StorageFile])',
        '$stream = Await ($storageFile.OpenAsync([Windows.Storage.FileAccessMode]::Read)) ([Windows.Storage.Streams.IRandomAccessStream])',
        '$decoder = Await ([Windows.Graphics.Imaging.BitmapDecoder]::CreateAsync($stream)) ([Windows.Graphics.Imaging.BitmapDecoder])',
        '$softwareBitmap = Await ($decoder.GetSoftwareBitmapAsync()) ([Windows.Graphics.Imaging.SoftwareBitmap])',
        '$ocrEngine = [Windows.Media.Ocr.OcrEngine]::TryCreateFromUserProfileLanguages()',
        'if ($null -eq $ocrEngine) {',
        '    $lang = New-Object Windows.Globalization.Language("en-US")',
        '    $ocrEngine = [Windows.Media.Ocr.OcrEngine]::TryCreateFromLanguage($lang)',
        '}',
        '$ocrResult = Await ($ocrEngine.RecognizeAsync($softwareBitmap)) ([Windows.Media.Ocr.OcrResult])',
        '$stream.Dispose()',
        '[System.IO.File]::WriteAllText($TextOut, $ocrResult.Text, [System.Text.Encoding]::UTF8)'
    ]

    PsCode := ""
    for _, Line in Lines
        PsCode .= Line "`r`n"

    try FileDelete(OcrScriptPath)
    FileAppend(PsCode, OcrScriptPath, "UTF-8")
}
